<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h5TGP4eqJBt38iFB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wKFraZkklyLPmvcA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m6I6t3lBUUcVkVbD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vbGL7ja8HbVchONQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getUser',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/addEvaluacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.AddEvaluacion',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/addEvaluacionDep' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.AddEvaluacionDep',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/updateQuestions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.updateQuestions',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/addQuestions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.addQuestions',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/evaluacionesDepartamento' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getEvaluacionesDepartamento',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/evaluaciones/resultado' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.Resultados',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/resultadosMejores' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'resultadosMejores.getMejoresResultados',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getUser',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/getFelicitacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getFelicitacion',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/getSugerencia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getSugerencia',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/getQueja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getQueja',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/addFelicitacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.addFelicitacion',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/addSugerencia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.addSugerencia',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/addQueja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.addQueja',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sos/reportes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.reportes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.getKpi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/addVacante' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.addVacante',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/addCandidato' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.addCandidato',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/updateCandidato' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.updateCandidato',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/updateContratacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.updateContratacion',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/updateVacante' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.updateVacante',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/getSolicitudPersonal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.getSolicitudPersonal',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kpi/createKpi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.createKpi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reserva' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sjcVrC4qSKSg32Bt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reserva/consultar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y5lwupnC3D2fZn2h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reserva/eliminarR' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MCZLjuXY6sbNpBAN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reserva/calcularDias' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bwMMvchpWcCJv5c3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reserva/verificarDias' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7oHUS1HdiZa6SDZk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store.get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'store.add',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hawoQzk21WXN5qa6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/menu/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.menu.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/move-up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.up',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/move-down' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.down',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/get-parents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sJNBDS1RlUIKwyko',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/element/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'menu.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'roles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/move/move-up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.up',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/move/move-down' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.down',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|evaluaciones/(?|de(?|s(?|empeno(?|/([^/]++)(*:58)|Edit/([^/]++)(*:78))|activarDepartamento/([^/]++)(*:114))|partamento(?|/([^/]++)(*:145)|Edit/([^/]++)(*:166)))|lider(?|/([^/]++)(*:193)|Edit/([^/]++)(*:214))|entreLideres(?|/([^/]++)(*:247)|Edit/([^/]++)(*:268))|climaLaboral(?|/([^/]++)(*:301)|Edit/([^/]++)(*:322))|g(?|rupal(?|/([^/]++)(*:352)|Edit/([^/]++)(*:373))|et(?|Questions/([^/]++)(*:405)|DesempenoValidacion/([^/]++)(*:441)|MostrarResultados/([^/]++)(*:475)|Sincontestar/([^/]++)(*:504)))|activarDepartamento/([^/]++)(*:542)|resultados(?|/(?|([^/]++)/([^/]++)(*:584)|aplicarSancion/([^/]++)/([^/]++)(*:624)|imprimir/([^/]++)/([^/]++)(*:658))|Lideres/([^/]++)/([^/]++)(*:692)|Dep/([^/]++)/([^/]++)(*:721)|Clima/([^/]++)(*:743)|Grupal(?|Contabilidad/([^/]++)(*:781)|LogisticaSoporte/([^/]++)(*:814))|lider/imprimir/([^/]++)/([^/]++)(*:855)|depa/imprimir/([^/]++)/([^/]++)(*:894)))|s(?|os/getReporte(?|Felicitacion/([^/]++)(*:945)|Sugerencia/([^/]++)(*:972)|Queja/([^/]++)(*:994))|tore/(?|([^/]++)(*:1019)|update(*:1034)|([^/]++)(*:1051)))|kpi/(?|get(?|Candidato/([^/]++)(*:1093)|Vacante/([^/]++)(*:1118)|Solicitud/([^/]++)(*:1145))|imprimir/([^/]++)(*:1172))|r(?|eserva/consultar/([^/]++)(*:1211)|oles/([^/]++)(?|(*:1236)|/edit(*:1250)|(*:1259)))|user/(?|([^/]++)(*:1286)|create(*:1301)|update(*:1316)))|/(.*)(*:1332))/?$}sDu',
    ),
    3 => 
    array (
      58 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsDesempeno',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsDesempenoEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.desactivarDepartamento',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsDepartamento',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      166 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsDepartamentoEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsLider',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      214 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsLiderEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      247 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsEntreLideres',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      268 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsEntreLideresEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsClimaLaboral',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      322 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsClimaLaboralEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      352 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsGrupal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestionsGrupalEdit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      405 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getQuestions',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.DesempenoValidacion',
          ),
          1 => 
          array (
            0 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      475 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getMostrarResultados',
          ),
          1 => 
          array (
            0 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getSincontestar',
          ),
          1 => 
          array (
            0 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      542 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.activarDepartamento',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      584 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultados',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.addSancion',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      658 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UVPf4upmWsPpIsKe',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      692 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultadosLider',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultadosDep',
          ),
          1 => 
          array (
            0 => 'idDep',
            1 => 'periodoDep',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultadosClima',
          ),
          1 => 
          array (
            0 => 'periodoCli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultadosGrupalContabilidad',
          ),
          1 => 
          array (
            0 => 'periodoCli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Evaluaciones.getResultadosGrupalLogisticaSoporte',
          ),
          1 => 
          array (
            0 => 'periodoCli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      855 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0KMQbaEa7e9ZgGIO',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'periodo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      894 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rz4412D8dkwkIVUC',
          ),
          1 => 
          array (
            0 => 'idDep',
            1 => 'periodoDep',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      945 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getReporteFelicitacion',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      972 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getReporteSugerencia',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      994 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sos.getReporteQueja',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1019 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1034 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store.update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store.destroyStore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1093 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.getCandidato',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1118 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.getVacante',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kpi.getSolicitud',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T7cL4ek2UG8N7i1Z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dYgb6N8xk0Y61AT0',
          ),
          1 => 
          array (
            0 => 'fecha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1236 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.show',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1250 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.edit',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1259 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'roles.update',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'roles.destroy',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1286 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qZgX3CklZpnWyw5w',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3zObuf9aCTPUqqNe',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EaSWnw0zV2wkWK32',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1332 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::REqaaQOWKSZ0Q0Av',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::h5TGP4eqJBt38iFB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuController@index',
        'controller' => 'App\\Http\\Controllers\\MenuController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::h5TGP4eqJBt38iFB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wKFraZkklyLPmvcA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::wKFraZkklyLPmvcA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m6I6t3lBUUcVkVbD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::m6I6t3lBUUcVkVbD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vbGL7ja8HbVchONQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@refresh',
        'controller' => 'App\\Http\\Controllers\\AuthController@refresh',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vbGL7ja8HbVchONQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getUser' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getUser',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getUser',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsDesempeno' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/desempeno/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDesempeno',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDesempeno',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsDesempeno',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsLider' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/lider/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsLider',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsLider',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsLider',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsEntreLideres' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/entreLideres/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsEntreLideres',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsEntreLideres',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsEntreLideres',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsClimaLaboral' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/climaLaboral/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsClimaLaboral',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsClimaLaboral',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsClimaLaboral',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsGrupal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/grupal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsGrupal',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsGrupal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsGrupal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsDepartamento' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/departamento/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDepartamento',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDepartamento',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsDepartamento',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsDesempenoEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/desempenoEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDesempenoEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDesempenoEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsDesempenoEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsLiderEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/liderEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsLiderEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsLiderEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsLiderEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsClimaLaboralEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/climaLaboralEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsClimaLaboralEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsClimaLaboralEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsClimaLaboralEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsDepartamentoEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/departamentoEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDepartamentoEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsDepartamentoEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsDepartamentoEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsGrupalEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/grupalEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsGrupalEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsGrupalEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsGrupalEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestionsEntreLideresEdit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/entreLideresEdit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsEntreLideresEdit',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestionsEntreLideresEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestionsEntreLideresEdit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.AddEvaluacion' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/evaluaciones/addEvaluacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@AddEvaluacion',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@AddEvaluacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.AddEvaluacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.AddEvaluacionDep' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/evaluaciones/addEvaluacionDep',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@AddEvaluacionDep',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@AddEvaluacionDep',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.AddEvaluacionDep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getQuestions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/getQuestions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestions',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getQuestions',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getQuestions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.updateQuestions' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/evaluaciones/updateQuestions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@updateQuestions',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@updateQuestions',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.updateQuestions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.addQuestions' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/evaluaciones/addQuestions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@addQuestions',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@addQuestions',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.addQuestions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getEvaluacionesDepartamento' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/evaluacionesDepartamento',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getEvaluacionesDepartamento',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getEvaluacionesDepartamento',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getEvaluacionesDepartamento',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.activarDepartamento' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/activarDepartamento/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@activarDepartamento',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@activarDepartamento',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.activarDepartamento',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.desactivarDepartamento' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/desactivarDepartamento/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@desactivarDepartamento',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@desactivarDepartamento',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.desactivarDepartamento',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.Resultados' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultado',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@Resultados',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@Resultados',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.Resultados',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.DesempenoValidacion' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/getDesempenoValidacion/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getDesempenoValidacion',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getDesempenoValidacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.DesempenoValidacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getMostrarResultados' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/getMostrarResultados/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getMostrarResultados',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getMostrarResultados',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getMostrarResultados',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getSincontestar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/getSincontestar/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getSincontestar',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getSincontestar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getSincontestar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultados' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultados/{id}/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultados',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultados',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultados',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultadosLider' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosLideres/{id}/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosLider',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosLider',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultadosLider',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.addSancion' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultados/aplicarSancion/{id}/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@addSancion',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@addSancion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.addSancion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultadosDep' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosDep/{idDep}/{periodoDep}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosDep',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosDep',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultadosDep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultadosClima' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosClima/{periodoCli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosClima',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosClima',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultadosClima',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultadosGrupalContabilidad' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosGrupalContabilidad/{periodoCli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosGrupalContabilidad',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosGrupalContabilidad',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultadosGrupalContabilidad',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Evaluaciones.getResultadosGrupalLogisticaSoporte' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosGrupalLogisticaSoporte/{periodoCli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosGrupalLogisticaSoporte',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@getResultadosGrupalLogisticaSoporte',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'Evaluaciones.getResultadosGrupalLogisticaSoporte',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0KMQbaEa7e9ZgGIO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadoslider/imprimir/{id}/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacionLider',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacionLider',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::0KMQbaEa7e9ZgGIO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UVPf4upmWsPpIsKe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultados/imprimir/{id}/{periodo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacion',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::UVPf4upmWsPpIsKe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rz4412D8dkwkIVUC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/evaluaciones/resultadosdepa/imprimir/{idDep}/{periodoDep}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacionDepa',
        'controller' => 'App\\Http\\Controllers\\EvaluacionesController@imprimirEvaluacionDepa',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/evaluaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::Rz4412D8dkwkIVUC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'resultadosMejores.getMejoresResultados' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/resultadosMejores',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MejoresResultadosController@getMejoresResultados',
        'controller' => 'App\\Http\\Controllers\\MejoresResultadosController@getMejoresResultados',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/resultadosMejores',
        'where' => 
        array (
        ),
        'as' => 'resultadosMejores.getMejoresResultados',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getUser' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getUser',
        'controller' => 'App\\Http\\Controllers\\SosController@getUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getUser',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getFelicitacion' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getFelicitacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getFelicitacion',
        'controller' => 'App\\Http\\Controllers\\SosController@getFelicitacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getFelicitacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getSugerencia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getSugerencia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getSugerencia',
        'controller' => 'App\\Http\\Controllers\\SosController@getSugerencia',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getSugerencia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getQueja' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getQueja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getQueja',
        'controller' => 'App\\Http\\Controllers\\SosController@getQueja',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getQueja',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.addFelicitacion' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sos/addFelicitacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@addFelicitacion',
        'controller' => 'App\\Http\\Controllers\\SosController@addFelicitacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.addFelicitacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.addSugerencia' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sos/addSugerencia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@addSugerencia',
        'controller' => 'App\\Http\\Controllers\\SosController@addSugerencia',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.addSugerencia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.addQueja' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sos/addQueja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@addQueja',
        'controller' => 'App\\Http\\Controllers\\SosController@addQueja',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.addQueja',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.reportes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/reportes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@reportes',
        'controller' => 'App\\Http\\Controllers\\SosController@reportes',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.reportes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getReporteFelicitacion' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getReporteFelicitacion/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getReporteFelicitacion',
        'controller' => 'App\\Http\\Controllers\\SosController@getReporteFelicitacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getReporteFelicitacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getReporteSugerencia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getReporteSugerencia/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getReporteSugerencia',
        'controller' => 'App\\Http\\Controllers\\SosController@getReporteSugerencia',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getReporteSugerencia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sos.getReporteQueja' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sos/getReporteQueja/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SosController@getReporteQueja',
        'controller' => 'App\\Http\\Controllers\\SosController@getReporteQueja',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/sos',
        'where' => 
        array (
        ),
        'as' => 'sos.getReporteQueja',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.getKpi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@getKpi',
        'controller' => 'App\\Http\\Controllers\\KpiController@getKpi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.getKpi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.addVacante' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/addVacante',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@addVacante',
        'controller' => 'App\\Http\\Controllers\\KpiController@addVacante',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.addVacante',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.addCandidato' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/addCandidato',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@addCandidato',
        'controller' => 'App\\Http\\Controllers\\KpiController@addCandidato',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.addCandidato',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.getCandidato' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi/getCandidato/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@getCandidato',
        'controller' => 'App\\Http\\Controllers\\KpiController@getCandidato',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.getCandidato',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.updateCandidato' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/updateCandidato',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@updateCandidato',
        'controller' => 'App\\Http\\Controllers\\KpiController@updateCandidato',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.updateCandidato',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.updateContratacion' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/updateContratacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@updateContratacion',
        'controller' => 'App\\Http\\Controllers\\KpiController@updateContratacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.updateContratacion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.getVacante' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi/getVacante/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@getVacante',
        'controller' => 'App\\Http\\Controllers\\KpiController@getVacante',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.getVacante',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.updateVacante' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/updateVacante',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@updateVacante',
        'controller' => 'App\\Http\\Controllers\\KpiController@updateVacante',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.updateVacante',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.getSolicitudPersonal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi/getSolicitudPersonal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@getSolicitudPersonal',
        'controller' => 'App\\Http\\Controllers\\KpiController@getSolicitudPersonal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.getSolicitudPersonal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.createKpi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kpi/createKpi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@createKpi',
        'controller' => 'App\\Http\\Controllers\\KpiController@createKpi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.createKpi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kpi.getSolicitud' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi/getSolicitud/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@getSolicitud',
        'controller' => 'App\\Http\\Controllers\\KpiController@getSolicitud',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'kpi.getSolicitud',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T7cL4ek2UG8N7i1Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kpi/imprimir/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\KpiController@imprimirkpi',
        'controller' => 'App\\Http\\Controllers\\KpiController@imprimirkpi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/kpi',
        'where' => 
        array (
        ),
        'as' => 'generated::T7cL4ek2UG8N7i1Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sjcVrC4qSKSg32Bt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reserva',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@index',
        'controller' => 'App\\Http\\Controllers\\ReservaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::sjcVrC4qSKSg32Bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y5lwupnC3D2fZn2h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reserva/consultar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@eliminarC',
        'controller' => 'App\\Http\\Controllers\\ReservaController@eliminarC',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::y5lwupnC3D2fZn2h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dYgb6N8xk0Y61AT0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reserva/consultar/{fecha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@eliminarE',
        'controller' => 'App\\Http\\Controllers\\ReservaController@eliminarE',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::dYgb6N8xk0Y61AT0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MCZLjuXY6sbNpBAN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reserva/eliminarR',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@eliminarR',
        'controller' => 'App\\Http\\Controllers\\ReservaController@eliminarR',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::MCZLjuXY6sbNpBAN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bwMMvchpWcCJv5c3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reserva/calcularDias',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@calcularDias',
        'controller' => 'App\\Http\\Controllers\\ReservaController@calcularDias',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::bwMMvchpWcCJv5c3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7oHUS1HdiZa6SDZk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reserva/verificarDias',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReservaController@verificarDias',
        'controller' => 'App\\Http\\Controllers\\ReservaController@verificarDias',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/reserva',
        'where' => 
        array (
        ),
        'as' => 'generated::7oHUS1HdiZa6SDZk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@Stores',
        'controller' => 'App\\Http\\Controllers\\SettingsController@Stores',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/store',
        'where' => 
        array (
        ),
        'as' => 'store.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/store/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@show',
        'controller' => 'App\\Http\\Controllers\\SettingsController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/store',
        'where' => 
        array (
        ),
        'as' => 'store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@updateStore',
        'controller' => 'App\\Http\\Controllers\\SettingsController@updateStore',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/store',
        'where' => 
        array (
        ),
        'as' => 'store.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store.add' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@addStore',
        'controller' => 'App\\Http\\Controllers\\SettingsController@addStore',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/store',
        'where' => 
        array (
        ),
        'as' => 'store.add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store.destroyStore' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/store/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@destroyStore',
        'controller' => 'App\\Http\\Controllers\\SettingsController@destroyStore',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/store',
        'where' => 
        array (
        ),
        'as' => 'store.destroyStore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hawoQzk21WXN5qa6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@Users',
        'controller' => 'App\\Http\\Controllers\\SettingsController@Users',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::hawoQzk21WXN5qa6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qZgX3CklZpnWyw5w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getUser',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::qZgX3CklZpnWyw5w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3zObuf9aCTPUqqNe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@addUser',
        'controller' => 'App\\Http\\Controllers\\SettingsController@addUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::3zObuf9aCTPUqqNe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EaSWnw0zV2wkWK32' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@updateUser',
        'controller' => 'App\\Http\\Controllers\\SettingsController@updateUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::EaSWnw0zV2wkWK32',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@index',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/menu/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@create',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/menu/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@store',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/menu/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@edit',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/menu/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@update',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.menu.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/menu/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuEditController@delete',
        'controller' => 'App\\Http\\Controllers\\MenuEditController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/menu',
        'where' => 
        array (
        ),
        'as' => 'menu.menu.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@index',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.up' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/move-up',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@moveUp',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@moveUp',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.up',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.down' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/move-down',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@moveDown',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@moveDown',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.down',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@create',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/element/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@store',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sJNBDS1RlUIKwyko' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/get-parents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@getParents',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@getParents',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'generated::sJNBDS1RlUIKwyko',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@edit',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/element/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@update',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@show',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'menu.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/menu/element/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuElementController@delete',
        'controller' => 'App\\Http\\Controllers\\MenuElementController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/menu/element',
        'where' => 
        array (
        ),
        'as' => 'menu.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.index',
        'uses' => 'App\\Http\\Controllers\\RolesController@index',
        'controller' => 'App\\Http\\Controllers\\RolesController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.create',
        'uses' => 'App\\Http\\Controllers\\RolesController@create',
        'controller' => 'App\\Http\\Controllers\\RolesController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.store',
        'uses' => 'App\\Http\\Controllers\\RolesController@store',
        'controller' => 'App\\Http\\Controllers\\RolesController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.show',
        'uses' => 'App\\Http\\Controllers\\RolesController@show',
        'controller' => 'App\\Http\\Controllers\\RolesController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/{role}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.edit',
        'uses' => 'App\\Http\\Controllers\\RolesController@edit',
        'controller' => 'App\\Http\\Controllers\\RolesController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.update',
        'uses' => 'App\\Http\\Controllers\\RolesController@update',
        'controller' => 'App\\Http\\Controllers\\RolesController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'as' => 'roles.destroy',
        'uses' => 'App\\Http\\Controllers\\RolesController@destroy',
        'controller' => 'App\\Http\\Controllers\\RolesController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.up' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/move/move-up',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\RolesController@moveUp',
        'controller' => 'App\\Http\\Controllers\\RolesController@moveUp',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'roles.up',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'roles.down' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/move/move-down',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\RolesController@moveDown',
        'controller' => 'App\\Http\\Controllers\\RolesController@moveDown',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'roles.down',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::REqaaQOWKSZ0Q0Av' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:269:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:51:"function () {
   return \\view(\'coreui.homepage\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000b5814aa00000000325f22c4";}";s:4:"hash";s:44:"iz/SdjK9RtXXF9nHJZ6LI3HFXuBZkQG87GiaZo+y1GE=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::REqaaQOWKSZ0Q0Av',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
