<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Resultados de Evaluaciones</title>
    <style>
        /** Define the margins of your page **/
       

        body {
            font-family: sans-serif; 
        }

        header {
            font-family: sans-serif;
            position: fixed;
            top: -60px;
            left: 0px;
            right: 0px;
            height: 50px;
        }

        #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        #customers td, #customers th {
        /* border: 1px solid #ddd;
        padding: 8px; */

        order: 1px solid black;
        /* border-collapse: collapse; */
        /* text-align: center; */
        }

        #customers tr:nth-child(even){
          background-color: #f2f2f2;

          order: 1px solid black;
          border-collapse: collapse;
        
        }

        #customers tr:hover {
          /* background-color: #ddd; */

          order: 1px solid black;
          border-collapse: collapse;  
        }

        #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: center;
        /* text-align: left; */
        background-color: black;
        color: white;

        
        }
    </style>

</head>
    <p style="text-align: right;"><span style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'>Fecha: <?php echo e($fecha); ?></span></p>
<p style="text-align: center;"><span style='text-align: center; font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 17px;'><strong><span style="color: rgb(85, 57, 130);">Evaluaciones del periodo: <?php echo e($periodo); ?></span></strong></span><span style='text-align: center; font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong><span style="color: rgb(85, 57, 130);">&nbsp;</span></strong></span><em style='text-align: center; font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'></em></p>
<p><span style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 15px;'><strong>Resultados de la evaluaci&oacute;n entre lideres:</strong>&nbsp;</span><span style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><em><?php echo e($usuarioEvaluado->name); ?> - <?php echo e($usuarioEvaluado->puesto); ?></em>&nbsp;</span></p>
<ul style="list-style-type: disc;">
    <li style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong>Evaluaci&oacute;n l&iacute;der: </strong><em><?php echo e($pdesempeno); ?></em></li>
    <li style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong>Numero de evaluaciones recibidas:</strong> <?php echo e($NoResultadosLider); ?></li>
    <li style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong>Numero de evaluaciones realizadas:</strong> <?php echo e($noEvaluacionesRealizadas); ?></li>
    <li style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong>Numero de evaluaciones esperadas:</strong> <?php echo e($noEvaluacionesEsperadas); ?></li>
    <li style='font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size: 14px;'><strong>Promedio de evaluaciones:</strong> <?php echo e($promedioLider); ?></li>
</ul>

<table id="customers">
  <tr>
    <th>Factores</th>
    <th>Promedio</th>
  </tr>
  <tr>
    <td>Apertura</td>
    <td><?php echo e($promediosFactoresLider[0]); ?></td>
  </tr>
  <tr>
    <td>Empatia</td>
    <td><?php echo e($promediosFactoresLider[1]); ?></td>
  </tr>
  <tr>
    <td>Pasion</td>
    <td><?php echo e($promediosFactoresLider[2]); ?></td>
  </tr>
  <tr>
    <td>Reconocimiento</td>
    <td><?php echo e($promediosFactoresLider[3]); ?></td>
  </tr>
  <tr>
    <td>Ideas</td>
    <td><?php echo e($promediosFactoresLider[4]); ?></td>
  </tr>
  <tr>
    <td>Maurez emocional</td>
    <td><?php echo e($promediosFactoresLider[5]); ?></td>
  </tr>
  <tr>
    <td>Participacion</td>
    <td><?php echo e($promediosFactoresLider[6]); ?></td>
  </tr>
  <tr>
    <td>Ejemplo</td>
    <td><?php echo e($promediosFactoresLider[7]); ?></td>
  </tr>
  <tr>
    <td>Conocimientos</td>
    <td><?php echo e($promediosFactoresLider[8]); ?></td>
  </tr>
  <tr>
    <td>Actitud</td>
    <td><?php echo e($promediosFactoresLider[9]); ?></td>
  </tr>
  <tr>
    <td>Positivo</td>
    <td><?php echo e($promediosFactoresLider[10]); ?></td>
  </tr>
  <tr>
    <td>Comunicacion asertiva</td>
    <td><?php echo e($promediosFactoresLider[11]); ?></td>
  </tr>
  <tr>
    <td>Resiliencia</td>
    <td><?php echo e($promediosFactoresLider[12]); ?></td>
  </tr>
  <tr>
    <td>Trabajo en equipo</td>
    <td><?php echo e($promediosFactoresLider[13]); ?></td>
  </tr>
  <tr>
    <td>Imagen</td>
    <td><?php echo e($promediosFactoresLider[14]); ?></td>
  </tr>
  <tr>
    <td>Enseñanza</td>
    <td><?php echo e($promediosFactoresLider[15]); ?></td>
  </tr>
  <tr>
    <td>Puntualidad</td>
    <td><?php echo e($promediosFactoresLider[16]); ?></td>
  </tr>
  <tr>
    <td>Convivencia</td>
    <td><?php echo e($promediosFactoresLider[17]); ?></td>
  </tr>
  <tr>
    <td>Respeto</td>
    <td><?php echo e($promediosFactoresLider[18]); ?></td>
  </tr>
  <tr>
    <td>Autocontrol</td>
    <td><?php echo e($promediosFactoresLider[19]); ?></td>
  </tr>
  <tr>
    <td>Procesos</td>
    <td><?php echo e($promediosFactoresLider[20]); ?></td>
  </tr>
  <tr>
    <td>KPi's</td>
    <td><?php echo e($promediosFactoresLider[21]); ?></td>
  </tr>
  <tr>
    <td>Servicio al cliente interno</td>
    <td><?php echo e($promediosFactoresLider[22]); ?></td>
  </tr>
</table>
<p></p> 
<p></p> 
<p></p> 
<p></p>
<p style="text-align: center;"><strong>______________________________</strong></p>
<p style="text-align: center;"><strong>Enterado de mi evaluaci&oacute;n</strong></p>

</body>
</html><?php /**PATH C:\Users\GWS\Documents\Evaluaciones\evaluacionesWS-main\laravel\resources\views\Reportes\evaluacion.blade.php ENDPATH**/ ?>