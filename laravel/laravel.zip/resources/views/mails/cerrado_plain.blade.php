Hola {{ $cerrado->usuario->name }} {{ $cerrado->usuario->primer_apellido }}

Ya cotizamos TU SISTEMA SOLAR, Puedes revisarla en el archivo anexo en este correo, recuerda que nuestro principal compromiso es el medio ambiente y tu familia.
Hagamos de la energía tu aliado.



Estás a un paso de adquirir tu SISTEMA SOLAR, Sigue avanzando, pronto estarás ahorrando y ayudando al medio ambiente. Únete tú también, a la familia WATT SOLAR

 
GWS GRUPO WATT SOLAR SA DE CV, Sólo recibe pagos en sus cuentas oficiales, si usted realiza algún depósito a algún tercero, éste no será válido, serán considerados como pagos, aquellos que estén única y exclusivamente acreditados en las cuentas de GWS GRUPO WATT SOLAR.

Este correo fue enviado desde una dirección solamente de notificaciones que no puede aceptar correo electrónico entrante. Por favor no respondas a este mensaje.