(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[60],{

/***/ "../coreui/src/views/media/Media.vue":
/*!*******************************************!*\
  !*** ../coreui/src/views/media/Media.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Media.vue?vue&type=template&id=5229c082& */ "../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082&");
/* harmony import */ var _Media_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Media.vue?vue&type=script&lang=js& */ "../coreui/src/views/media/Media.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Media_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/media/Media.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/media/Media.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ../coreui/src/views/media/Media.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Media_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Media.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/media/Media.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Media_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082&":
/*!**************************************************************************!*\
  !*** ../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082& ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Media.vue?vue&type=template&id=5229c082& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Media_vue_vue_type_template_id_5229c082___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/media/Media.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/media/Media.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "../coreui/node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var cropperjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cropperjs */ "../coreui/node_modules/cropperjs/dist/cropper.js");
/* harmony import */ var cropperjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cropperjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var cropperjs_dist_cropper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! cropperjs/dist/cropper.css */ "../coreui/node_modules/cropperjs/dist/cropper.css");
/* harmony import */ var cropperjs_dist_cropper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(cropperjs_dist_cropper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _coreui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @coreui/icons */ "../coreui/node_modules/@coreui/icons/js/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  plusIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_3__["cilPlus"],
  folderIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_3__["cilFolder"],
  fileIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_3__["cilFile"],
  levelUpIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_3__["cilLevelUp"],
  name: 'Media',
  data: function data() {
    return {
      rightCard: 'fileInfo',
      elementId: null,
      thisFolder: null,
      name: null,
      medias: [],
      mediaFolders: [],
      parentFolder: 'disable',
      fields: ['name', 'actions'],
      items: [],
      returnFolderId: null,
      fileInfoHeader: ['name', 'data'],
      fileInfo: [],
      selectFolder: null,
      moveObjectName: '',
      deleteFolderModal: false,
      deleteFileModal: false,
      downloadFileName: '',
      croppModal: false,
      cropper: null,
      croppUrl: '',
      changePort: 'localhost:8000'
    };
  },
  computed: {
    selectFolderArray: function selectFolderArray() {
      var self = this;
      return this.mediaFolders.filter(function (u) {
        return u.id != self.elementId;
      });
    }
  },
  methods: {
    croppImage: function croppImage() {
      var _this = this;

      var self = this;
      self.cropper.getCroppedCanvas().toBlob(function (blob) {
        var formData = new FormData();
        formData.append('file', blob);
        formData.append('thisFolder', self.thisFolder);
        formData.append('id', self.elementId);
        formData.append('token', localStorage.getItem("api_token"));
        axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(_this.$apiAdress + '/api/media/file/cropp', formData).then(function (response) {
          self.croppModal = false;
          self.getFoldersAndFiles(self.thisFolder);
        })["catch"](function (error) {
          console.log(error);
        });
      }
      /*, 'image/png' */
      );
    },
    openCroppFileModal: function openCroppFileModal(id) {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/file?id=' + id + '&thisFolder=' + self.thisFolder + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.elementId = response.data.id;
        self.croppUrl = response.data.url;
        self.croppUrl = self.croppUrl.replace('localhost', self.changePort);
        document.getElementById('cropp-img-img').setAttribute('src', self.croppUrl);
        self.croppModal = true;
        self.$nextTick(function () {
          if (self.cropper !== null) {
            self.cropper.replace(self.croppUrl);
          } else {
            self.cropper = new cropperjs__WEBPACK_IMPORTED_MODULE_1___default.a(document.getElementById('cropp-img-img'), {
              minContainerWidth: 600,
              minContainerHeight: 600
            });
          }
        });
      })["catch"](function (error) {
        console.log(error);
      });
    },
    downloadFile: function downloadFile(id, name) {
      var self = this;
      this.downloadFileName = name;
      axios__WEBPACK_IMPORTED_MODULE_0___default()({
        method: 'get',
        url: this.$apiAdress + '/api/media/file/download?thisFolder=' + self.thisFolder + '&id=' + id + '&token=' + localStorage.getItem("api_token"),
        responseType: 'arraybuffer'
      }).then(function (response) {
        var url = window.URL.createObjectURL(new Blob([response.data]));
        var link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', self.downloadFileName);
        document.body.appendChild(link);
        link.click();
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    openDeleteDialog: function openDeleteDialog(id, type, name) {
      this.moveObjectName = name;
      this.elementId = id;

      if (type == 'folder') {
        this.deleteFolderModal = true;
      } else {
        this.deleteFileModal = true;
      }
    },
    deleteFolder: function deleteFolder() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/folder/delete?thisFolder=' + self.thisFolder + '&id=' + self.elementId + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
        self.rightCard = 'fileInfo';
        self.deleteFolderModal = false;
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    deleteFile: function deleteFile() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/file/delete?thisFolder=' + self.thisFolder + '&id=' + self.elementId + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
        self.rightCard = 'fileInfo';
        self.deleteFileModal = false;
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    selectFolderRadioInput: function selectFolderRadioInput(data) {
      this.selectFolder = data;
    },
    returnFolder: function returnFolder() {
      if (this.returnFolderId != null) {
        this.getFoldersAndFiles(this.returnFolderId);
      }
    },
    clickOnElement: function clickOnElement(id, type) {
      if (type == 'folder') {
        this.returnFolderId = this.thisFolder;
        this.getFoldersAndFiles(id);
      } else {
        this.getFileInfo(id);
      }
    },
    renameOpenForm: function renameOpenForm(id, type) {
      this.elementId = id;
      var self = this;

      if (type == 'folder') {
        axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/folder?id=' + id + '&token=' + localStorage.getItem("api_token")).then(function (response) {
          self.name = response.data.name;
          self.rightCard = 'renameFolder';
        })["catch"](function (error) {
          console.log(error);
          self.$router.push({
            path: '/login'
          });
        });
      } else {
        axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/file?thisFolder=' + self.thisFolder + '&id=' + id + '&token=' + localStorage.getItem("api_token")).then(function (response) {
          self.name = response.data.name;
          self.rightCard = 'renameFile';
        })["catch"](function (error) {
          console.log(error);
          self.$router.push({
            path: '/login'
          });
        });
      }
    },
    moveOpenForm: function moveOpenForm(id, type, objectName) {
      this.elementId = id;
      this.moveObjectName = objectName;

      if (type == 'folder') {
        this.rightCard = 'moveFolder';
      } else {
        this.rightCard = 'moveFile';
      }
    },
    moveFolder: function moveFolder() {
      if (this.selectFolder != null) {
        var self = this;
        axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/folder/move', {
          id: this.elementId,
          folder: this.selectFolder,
          token: localStorage.getItem("api_token")
        }).then(function (response) {
          self.getFoldersAndFiles(self.thisFolder);
          self.rightCard = 'fileInfo';
          self.selectFolder = null;
        })["catch"](function (error) {
          console.log(error);
          self.$router.push({
            path: '/login'
          });
        });
      }
    },
    moveFile: function moveFile() {
      if (this.selectFolder != null) {
        var self = this;
        axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/file/move', {
          id: this.elementId,
          folder: this.selectFolder,
          thisFolder: this.thisFolder,
          token: localStorage.getItem("api_token")
        }).then(function (response) {
          self.getFoldersAndFiles(self.thisFolder);
          self.rightCard = 'fileInfo';
          self.selectFolder = null;
        })["catch"](function (error) {
          console.log(error);
          self.$router.push({
            path: '/login'
          });
        });
      }
    },
    copyFile: function copyFile(id) {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/file/copy?thisFolder=' + self.thisFolder + '&id=' + id + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
        self.rightCard = 'fileInfo';
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    renameFolder: function renameFolder() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/folder/update', {
        name: this.name,
        id: this.elementId,
        token: localStorage.getItem("api_token")
      }).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
        self.rightCard = 'fileInfo';
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    renameFile: function renameFile() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/file/update', {
        name: this.name,
        id: this.elementId,
        token: localStorage.getItem("api_token"),
        thisFolder: this.thisFolder
      }).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
        self.rightCard = 'fileInfo';
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    getFileInfo: function getFileInfo(id) {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/file?thisFolder=' + self.thisFolder + '&id=' + id + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.fileInfo = [];
        self.fileInfo.push({
          name: 'Name',
          data: response.data['name']
        });
        self.fileInfo.push({
          name: 'Real name',
          data: response.data['realName']
        });
        self.fileInfo.push({
          name: 'URL',
          data: response.data['url']
        });
        self.fileInfo.push({
          name: 'Mime Type',
          data: response.data['mimeType']
        });
        self.fileInfo.push({
          name: 'Size',
          data: response.data['size']
        });
        self.fileInfo.push({
          name: 'Created At',
          data: response.data['createdAt']
        });
        self.fileInfo.push({
          name: 'Updated At',
          data: response.data['updatedAt']
        });
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    handleFileUpload: function handleFileUpload(files, event) {
      var self = this;
      var formData = new FormData();
      formData.append('file', files[0]);
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/media/file/store?thisFolder=' + self.thisFolder + '&token=' + localStorage.getItem("api_token"), formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(function () {
        self.getFoldersAndFiles(self.thisFolder);
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    addFolder: function addFolder() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media/folder/store?thisFolder=' + self.thisFolder + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.getFoldersAndFiles(self.thisFolder);
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    },
    buildItems: function buildItems() {
      this.items = [];

      for (var i = 0; i < this.mediaFolders.length; i++) {
        this.items.push({
          type: 'folder',
          name: this.mediaFolders[i].name,
          id: this.mediaFolders[i].id
        });
      }

      for (var i = 0; i < this.medias.length; i++) {
        this.items.push({
          type: 'file',
          name: this.medias[i].name,
          id: this.medias[i].id,
          url: this.medias[i].url,
          mime: this.medias[i].mime_type
        });
      }
    },
    getFoldersAndFiles: function getFoldersAndFiles(folderId) {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/media?id=' + folderId + '&token=' + localStorage.getItem("api_token")).then(function (response) {
        self.medias = response.data.medias;
        self.mediaFolders = response.data.mediaFolders;
        self.thisFolder = response.data.thisFolder;
        self.parentFolder = response.data.parentFolder;
        self.buildItems();
        self.rightCard = 'fileInfo';
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    }
  },
  mounted: function mounted() {
    this.getFoldersAndFiles('');
    document.getElementById('cropp-img-img').addEventListener('load', this.updateCroppImage);
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/media/Media.vue?vue&type=template&id=5229c082& ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "CRow",
    [
      _c(
        "CCol",
        { attrs: { col: "12", xl: "6" } },
        [
          _c(
            "transition",
            { attrs: { name: "slide" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardBody",
                    [
                      _c("h4", [_vm._v("Media")]),
                      _vm._v(" "),
                      _vm.parentFolder != "disable"
                        ? _c(
                            "CButton",
                            {
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  return _vm.returnFolder()
                                },
                              },
                            },
                            [
                              _c("CIcon", {
                                attrs: { content: _vm.$options.levelUpIcon },
                              }),
                              _vm._v("\n              Return\n          "),
                            ],
                            1
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "CButton",
                        {
                          attrs: { color: "primary" },
                          on: {
                            click: function ($event) {
                              return _vm.addFolder()
                            },
                          },
                        },
                        [
                          _c("CIcon", {
                            attrs: { content: _vm.$options.plusIcon },
                          }),
                          _vm._v(" "),
                          _c("CIcon", {
                            attrs: { content: _vm.$options.folderIcon },
                          }),
                          _vm._v("\n              New folder\n          "),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("CIcon", {
                        attrs: { content: _vm.$options.plusIcon },
                      }),
                      _vm._v(" "),
                      _c("CIcon", {
                        attrs: { content: _vm.$options.fileIcon },
                      }),
                      _vm._v(" "),
                      _c("CInputFile", {
                        attrs: { type: "file", placeholder: "New file" },
                        on: { change: _vm.handleFileUpload },
                      }),
                      _vm._v(" "),
                      _c("CDataTable", {
                        attrs: {
                          hover: "",
                          items: _vm.items,
                          fields: _vm.fields,
                        },
                        scopedSlots: _vm._u([
                          {
                            key: "name",
                            fn: function (ref) {
                              var item = ref.item
                              return [
                                item.type == "folder"
                                  ? _c(
                                      "td",
                                      {
                                        staticClass: "click-file",
                                        on: {
                                          click: function ($event) {
                                            return _vm.clickOnElement(
                                              item.id,
                                              item.type
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c("CIcon", {
                                          attrs: {
                                            content: _vm.$options.folderIcon,
                                          },
                                        }),
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(item.name) +
                                            "\n                "
                                        ),
                                      ],
                                      1
                                    )
                                  : _c(
                                      "td",
                                      {
                                        staticClass: "click-file",
                                        on: {
                                          click: function ($event) {
                                            return _vm.clickOnElement(
                                              item.id,
                                              item.type
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c("CIcon", {
                                          attrs: {
                                            content: _vm.$options.fileIcon,
                                          },
                                        }),
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(item.name) +
                                            "\n                "
                                        ),
                                      ],
                                      1
                                    ),
                              ]
                            },
                          },
                          {
                            key: "actions",
                            fn: function (ref) {
                              var item = ref.item
                              return [
                                _c(
                                  "td",
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: { color: "primary" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.renameOpenForm(
                                              item.id,
                                              item.type
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                      Rename\n                  "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "td",
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: { color: "primary" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.moveOpenForm(
                                              item.id,
                                              item.type,
                                              item.name
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                      Move\n                  "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                item.type == "file"
                                  ? _c(
                                      "td",
                                      [
                                        _c(
                                          "CButton",
                                          {
                                            attrs: { color: "primary" },
                                            on: {
                                              click: function ($event) {
                                                return _vm.copyFile(item.id)
                                              },
                                            },
                                          },
                                          [
                                            _vm._v(
                                              "\n                      Copy\n                  "
                                            ),
                                          ]
                                        ),
                                      ],
                                      1
                                    )
                                  : _c("td"),
                                _vm._v(" "),
                                item.type == "file"
                                  ? _c(
                                      "td",
                                      [
                                        _c(
                                          "CButton",
                                          {
                                            attrs: { color: "primary" },
                                            on: {
                                              click: function ($event) {
                                                return _vm.downloadFile(
                                                  item.id,
                                                  item.name
                                                )
                                              },
                                            },
                                          },
                                          [
                                            _vm._v(
                                              "\n                      Download\n                  "
                                            ),
                                          ]
                                        ),
                                      ],
                                      1
                                    )
                                  : _c("td"),
                                _vm._v(" "),
                                item.type == "file"
                                  ? _c(
                                      "td",
                                      [
                                        item.mime.includes("image/")
                                          ? _c(
                                              "CButton",
                                              {
                                                attrs: { color: "success" },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.openCroppFileModal(
                                                      item.id
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                      Cropp\n                  "
                                                ),
                                              ]
                                            )
                                          : _vm._e(),
                                      ],
                                      1
                                    )
                                  : _c("td"),
                                _vm._v(" "),
                                _c(
                                  "td",
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: { color: "danger" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.openDeleteDialog(
                                              item.id,
                                              item.type,
                                              item.name
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                      Delete\n                  "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12", xl: "6" } },
        [
          _c(
            "transition",
            { attrs: { name: "slide" } },
            [
              _vm.rightCard == "fileInfo"
                ? _c(
                    "CCard",
                    [
                      _c(
                        "CCardBody",
                        [
                          _c("CDataTable", {
                            attrs: {
                              items: _vm.fileInfo,
                              fields: _vm.fileInfoHeader,
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.rightCard == "renameFolder"
                ? _c(
                    "CCard",
                    [
                      _c(
                        "CCardBody",
                        [
                          _c("CInput", {
                            attrs: {
                              type: "text",
                              label: "New name",
                              placeholder: "Folder name",
                            },
                            model: {
                              value: _vm.name,
                              callback: function ($$v) {
                                _vm.name = $$v
                              },
                              expression: "name",
                            },
                          }),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  return _vm.renameFolder()
                                },
                              },
                            },
                            [_vm._v("\n              Save\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  _vm.rightCard = "fileInfo"
                                },
                              },
                            },
                            [_vm._v("\n              Cancel\n          ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.rightCard == "renameFile"
                ? _c(
                    "CCard",
                    [
                      _c(
                        "CCardBody",
                        [
                          _c("CInput", {
                            attrs: {
                              type: _vm.text,
                              label: "New name",
                              placeholder: "Folder name",
                            },
                            model: {
                              value: _vm.name,
                              callback: function ($$v) {
                                _vm.name = $$v
                              },
                              expression: "name",
                            },
                          }),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  return _vm.renameFile()
                                },
                              },
                            },
                            [_vm._v("\n              Save\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  _vm.rightCard = "fileInfo"
                                },
                              },
                            },
                            [_vm._v("\n              Cancel\n          ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.rightCard == "moveFolder"
                ? _c(
                    "CCard",
                    [
                      _c(
                        "CCardBody",
                        [
                          _c("h4", [
                            _vm._v(
                              'Move folder "' + _vm._s(_vm.moveObjectName) + '"'
                            ),
                          ]),
                          _vm._v(" "),
                          _vm.parentFolder != "disable"
                            ? _c("CInputRadio", {
                                attrs: {
                                  label: "Move Up",
                                  type: "radio",
                                  name: "selectFolderForFolder",
                                },
                                on: {
                                  "update:checked": function ($event) {
                                    return _vm.selectFolderRadioInput("moveUp")
                                  },
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm._l(_vm.selectFolderArray, function (item) {
                            return _c("CInputRadio", {
                              key: item.id,
                              attrs: {
                                label: item.name,
                                type: "radio",
                                name: "selectFolderForFolder",
                              },
                              on: {
                                "update:checked": function ($event) {
                                  return _vm.selectFolderRadioInput(item.id)
                                },
                              },
                            })
                          }),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              staticClass: "mt-4",
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  return _vm.moveFolder()
                                },
                              },
                            },
                            [_vm._v("\n              Save\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              staticClass: "mt-4",
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  _vm.rightCard = "fileInfo"
                                },
                              },
                            },
                            [_vm._v("\n              Cancel\n          ")]
                          ),
                        ],
                        2
                      ),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.rightCard == "moveFile"
                ? _c(
                    "CCard",
                    [
                      _c(
                        "CCardBody",
                        [
                          _c("h4", [
                            _vm._v(
                              'Move file "' + _vm._s(_vm.moveObjectName) + '"'
                            ),
                          ]),
                          _vm._v(" "),
                          _vm.parentFolder != "disable"
                            ? _c("CInputRadio", {
                                attrs: {
                                  label: "Move Up",
                                  type: "radio",
                                  name: "selectFolderForFolder",
                                },
                                on: {
                                  "update:checked": function ($event) {
                                    return _vm.selectFolderRadioInput("moveUp")
                                  },
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm._l(_vm.mediaFolders, function (item) {
                            return _c("CInputRadio", {
                              key: item.id,
                              attrs: {
                                label: item.name,
                                type: "radio",
                                name: "selectFolderForFolder",
                              },
                              on: {
                                "update:checked": function ($event) {
                                  return _vm.selectFolderRadioInput(item.id)
                                },
                              },
                            })
                          }),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              staticClass: "mt-4",
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  return _vm.moveFile()
                                },
                              },
                            },
                            [_vm._v("\n              Save\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              staticClass: "mt-4",
                              attrs: { color: "primary" },
                              on: {
                                click: function ($event) {
                                  _vm.rightCard = "fileInfo"
                                },
                              },
                            },
                            [_vm._v("\n              Cancel\n          ")]
                          ),
                        ],
                        2
                      ),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CModal",
        {
          attrs: {
            show: _vm.deleteFolderModal,
            centered: true,
            title: "Delete folder",
          },
          on: {
            "update:show": function ($event) {
              _vm.deleteFolderModal = $event
            },
          },
          scopedSlots: _vm._u([
            {
              key: "footer",
              fn: function () {
                return [
                  _c(
                    "CButton",
                    {
                      attrs: { color: "primary" },
                      on: {
                        click: function ($event) {
                          _vm.deleteFolderModal = false
                        },
                      },
                    },
                    [_vm._v("Cancel")]
                  ),
                  _vm._v(" "),
                  _c(
                    "CButton",
                    {
                      attrs: { color: "danger" },
                      on: { click: _vm.deleteFolder },
                    },
                    [_vm._v("Delete")]
                  ),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [
          _vm._v(
            '\n      Are you sure to delete a folder named "' +
              _vm._s(_vm.moveObjectName) +
              '"?\n    '
          ),
        ]
      ),
      _vm._v(" "),
      _c(
        "CModal",
        {
          attrs: {
            show: _vm.deleteFileModal,
            centered: true,
            title: "Delete file",
          },
          on: {
            "update:show": function ($event) {
              _vm.deleteFileModal = $event
            },
          },
          scopedSlots: _vm._u([
            {
              key: "footer",
              fn: function () {
                return [
                  _c(
                    "CButton",
                    {
                      attrs: { color: "primary" },
                      on: {
                        click: function ($event) {
                          _vm.deleteFileModal = false
                        },
                      },
                    },
                    [_vm._v("Cancel")]
                  ),
                  _vm._v(" "),
                  _c(
                    "CButton",
                    {
                      attrs: { color: "danger" },
                      on: { click: _vm.deleteFile },
                    },
                    [_vm._v("Delete")]
                  ),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [
          _vm._v(
            '\n      Are you sure to delete a file named "' +
              _vm._s(_vm.moveObjectName) +
              '"?\n    '
          ),
        ]
      ),
      _vm._v(" "),
      _c(
        "CModal",
        {
          attrs: {
            show: _vm.croppModal,
            centered: true,
            title: "Cropp image",
            size: "lg",
          },
          on: {
            "update:show": function ($event) {
              _vm.croppModal = $event
            },
          },
          scopedSlots: _vm._u([
            {
              key: "footer",
              fn: function () {
                return [
                  _c(
                    "CButton",
                    {
                      attrs: { color: "primary" },
                      on: {
                        click: function ($event) {
                          _vm.croppModal = false
                        },
                      },
                    },
                    [_vm._v("Cancel")]
                  ),
                  _vm._v(" "),
                  _c(
                    "CButton",
                    {
                      attrs: { color: "primary" },
                      on: { click: _vm.croppImage },
                    },
                    [_vm._v("Cropp")]
                  ),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [_c("img", { attrs: { id: "cropp-img-img" } })]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);