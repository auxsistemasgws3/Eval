(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[31],{

/***/ "../coreui/src/views/sos/ResultadosSos.vue":
/*!*************************************************!*\
  !*** ../coreui/src/views/sos/ResultadosSos.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ResultadosSos.vue?vue&type=template&id=8620a83e& */ "../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e&");
/* harmony import */ var _ResultadosSos_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ResultadosSos.vue?vue&type=script&lang=js& */ "../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ResultadosSos_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/sos/ResultadosSos.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ResultadosSos_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./ResultadosSos.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ResultadosSos_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e&":
/*!********************************************************************************!*\
  !*** ../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e& ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./ResultadosSos.vue?vue&type=template&id=8620a83e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ResultadosSos_vue_vue_type_template_id_8620a83e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/sos/ResultadosSos.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\coreui\\src\\views\\sos\\ResultadosSos.vue: Unexpected token, expected \",\" (311:2)\n\n\u001b[0m \u001b[90m 309 |\u001b[39m   { key\u001b[33m:\u001b[39m \u001b[32m\"sucursal_desc\"\u001b[39m\u001b[33m,\u001b[39m label\u001b[33m:\u001b[39m \u001b[32m\"Sucursal\"\u001b[39m\u001b[33m,\u001b[39m _style\u001b[33m:\u001b[39m \u001b[32m\"min-width:100px;\"\u001b[39m }\u001b[33m,\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 310 |\u001b[39m   {key\u001b[33m:\u001b[39m\u001b[32m\"fecha_realizada\"\u001b[39m\u001b[33m,\u001b[39m label\u001b[33m:\u001b[39m\u001b[32m\"feche\"\u001b[39m\u001b[33m,\u001b[39mstyle\u001b[33m:\u001b[39m\u001b[32m\"min-width:100px;\"\u001b[39m}\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 311 |\u001b[39m   { key\u001b[33m:\u001b[39m \u001b[32m\"show_details\"\u001b[39m\u001b[33m,\u001b[39m label\u001b[33m:\u001b[39m \u001b[32m\"\"\u001b[39m\u001b[33m,\u001b[39m _style\u001b[33m:\u001b[39m \u001b[32m\"width:1%\"\u001b[39m\u001b[33m,\u001b[39m sorter\u001b[33m:\u001b[39m \u001b[36mfalse\u001b[39m\u001b[33m,\u001b[39m filter\u001b[33m:\u001b[39m \u001b[36mfalse\u001b[39m\u001b[33m,\u001b[39m }\u001b[33m,\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m     |\u001b[39m   \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 312 |\u001b[39m ]\u001b[33m;\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 313 |\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 314 |\u001b[39m \u001b[36mexport\u001b[39m \u001b[36mdefault\u001b[39m {\u001b[0m\n    at Parser._raise (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:541:17)\n    at Parser.raiseWithData (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:534:17)\n    at Parser.raise (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:495:17)\n    at Parser.unexpected (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:3580:16)\n    at Parser.expect (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:3554:28)\n    at Parser.parseExprList (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:12832:14)\n    at Parser.parseArrayLike (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:12735:26)\n    at Parser.parseExprAtom (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11902:23)\n    at Parser.parseExprSubscripts (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11584:23)\n    at Parser.parseUpdate (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11564:21)\n    at Parser.parseMaybeUnary (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11539:23)\n    at Parser.parseMaybeUnaryOrPrivate (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11353:61)\n    at Parser.parseExprOps (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11360:23)\n    at Parser.parseMaybeConditional (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11330:23)\n    at Parser.parseMaybeAssign (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11290:21)\n    at C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11248:39\n    at Parser.allowInAnd (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13131:16)\n    at Parser.parseMaybeAssignAllowIn (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:11248:17)\n    at Parser.parseVar (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:14022:70)\n    at Parser.parseVarStatement (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13836:10)\n    at Parser.parseStatementContent (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13421:21)\n    at Parser.parseStatement (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13352:17)\n    at Parser.parseBlockOrModuleBlockBody (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13941:25)\n    at Parser.parseBlockBody (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13932:10)\n    at Parser.parseProgram (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13272:10)\n    at Parser.parseTopLevel (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:13263:25)\n    at Parser.parse (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:15037:10)\n    at parse (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\parser\\lib\\index.js:15089:38)\n    at parser (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\core\\lib\\parser\\index.js:52:34)\n    at parser.next (<anonymous>)\n    at normalizeFile (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\core\\lib\\transformation\\normalize-file.js:87:38)\n    at normalizeFile.next (<anonymous>)\n    at run (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\core\\lib\\transformation\\index.js:29:50)\n    at run.next (<anonymous>)\n    at Function.transform (C:\\Users\\GWS\\Documents\\Evaluaciones\\evaluacionesWS-main\\laravel\\node_modules\\@babel\\core\\lib\\transform.js:25:41)\n    at transform.next (<anonymous>)");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/sos/ResultadosSos.vue?vue&type=template&id=8620a83e& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "CCard",
        [
          _c(
            "CCardHeader",
            [
              _c("CIcon", {
                staticClass: "mt-1",
                attrs: { name: "cil-speedometer", size: "xl" },
              }),
              _vm._v("\n       \n      "),
              _c("span", { staticClass: "h4" }, [_vm._v("Reportes S.O.S. ")]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CTabs",
            {
              attrs: { "active-tab": _vm.activeTab },
              on: {
                "update:activeTab": function ($event) {
                  _vm.activeTab = $event
                },
                "update:active-tab": function ($event) {
                  _vm.activeTab = $event
                },
              },
            },
            [
              _c(
                "CTab",
                [
                  _c(
                    "template",
                    { slot: "title" },
                    [
                      _c("CIcon", {
                        attrs: {
                          name:
                            _vm.activeTab === 1
                              ? "cil-folder-open"
                              : "cil-folder",
                        },
                      }),
                      _vm._v(" Felicitaciones\n        "),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CRow", [_c("CCol", [_vm._v(" ")])], 1),
                  _vm._v("\n        " + _vm._s(_vm.items) + "\n        "),
                  _c(
                    "CCardBody",
                    [
                      _c("CDataTable", {
                        attrs: {
                          items: _vm.items,
                          fields: _vm.fields,
                          tableFilter: {
                            placeholder: _vm.$t("tables.filter.placeholder"),
                            label: _vm.$t("tables.filter.label") + ":",
                            lazy: true,
                          },
                          itemsPerPageSelect: {
                            label: _vm.$t("tables.pageSelect") + ":",
                          },
                          noItemsView: {
                            noResults: _vm.$t("tables.itemsView.noResults"),
                            noItems: _vm.$t("tables.itemsView.noItems"),
                          },
                          "items-per-page": 15,
                          hover: "",
                          columnFilter: "",
                          sorter: "",
                          pagination: "",
                          outlined: "",
                          size: "sm",
                          loading: _vm.loading,
                        },
                        scopedSlots: _vm._u([
                          {
                            key: "show_details",
                            fn: function (ref) {
                              var item = ref.item
                              return [
                                _c(
                                  "td",
                                  { staticClass: "py-2" },
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: {
                                          color: "success",
                                          variant: "outline",
                                          square: "",
                                          size: "sm",
                                        },
                                        on: {
                                          click: function ($event) {
                                            return _vm.getReporteFelicitacion(
                                              item.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  Resultados\n                "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "CTab",
                [
                  _c(
                    "template",
                    { slot: "title" },
                    [
                      _c("CIcon", {
                        attrs: {
                          name:
                            _vm.activeTab === 1
                              ? "cil-folder-open"
                              : "cil-folder",
                        },
                      }),
                      _vm._v(" Sugerencias de Mejora\n        "),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CRow", [_c("CCol", [_vm._v(" ")])], 1),
                  _vm._v(" "),
                  _c(
                    "CCardBody",
                    [
                      _c("CDataTable", {
                        attrs: {
                          items: _vm.items2,
                          fields: _vm.fields,
                          tableFilter: {
                            placeholder: _vm.$t("tables.filter.placeholder"),
                            label: _vm.$t("tables.filter.label") + ":",
                            lazy: true,
                          },
                          itemsPerPageSelect: {
                            label: _vm.$t("tables.pageSelect") + ":",
                          },
                          noItemsView: {
                            noResults: _vm.$t("tables.itemsView.noResults"),
                            noItems: _vm.$t("tables.itemsView.noItems"),
                          },
                          "items-per-page": 15,
                          hover: "",
                          columnFilter: "",
                          sorter: "",
                          pagination: "",
                          outlined: "",
                          size: "sm",
                          loading: _vm.loading,
                        },
                        scopedSlots: _vm._u([
                          {
                            key: "show_details",
                            fn: function (ref) {
                              var item = ref.item
                              return [
                                _c(
                                  "td",
                                  { staticClass: "py-2" },
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: {
                                          color: "success",
                                          variant: "outline",
                                          square: "",
                                          size: "sm",
                                        },
                                        on: {
                                          click: function ($event) {
                                            return _vm.getReporteSugerencia(
                                              item.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  Resultados\n                "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "CTab",
                [
                  _c(
                    "template",
                    { slot: "title" },
                    [
                      _c("CIcon", {
                        attrs: {
                          name:
                            _vm.activeTab === 1
                              ? "cil-folder-open"
                              : "cil-folder",
                        },
                      }),
                      _vm._v(" Queja\n        "),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CRow", [_c("CCol", [_vm._v(" ")])], 1),
                  _vm._v(" "),
                  _c(
                    "CCardBody",
                    [
                      _c("CDataTable", {
                        attrs: {
                          items: _vm.items3,
                          fields: _vm.fields,
                          tableFilter: {
                            placeholder: _vm.$t("tables.filter.placeholder"),
                            label: _vm.$t("tables.filter.label") + ":",
                            lazy: true,
                          },
                          itemsPerPageSelect: {
                            label: _vm.$t("tables.pageSelect") + ":",
                          },
                          noItemsView: {
                            noResults: _vm.$t("tables.itemsView.noResults"),
                            noItems: _vm.$t("tables.itemsView.noItems"),
                          },
                          "items-per-page": 15,
                          hover: "",
                          columnFilter: "",
                          sorter: "",
                          pagination: "",
                          outlined: "",
                          size: "sm",
                          loading: _vm.loading,
                        },
                        scopedSlots: _vm._u([
                          {
                            key: "show_details",
                            fn: function (ref) {
                              var item = ref.item
                              return [
                                _c(
                                  "td",
                                  { staticClass: "py-2" },
                                  [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: {
                                          color: "success",
                                          variant: "outline",
                                          square: "",
                                          size: "sm",
                                        },
                                        on: {
                                          click: function ($event) {
                                            return _vm.getReporteQueja(item.id)
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  Resultados\n                "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "CModal",
                {
                  attrs: {
                    entered: true,
                    title: "S.O.S. Felicitaciónes",
                    size: "xl",
                    show: _vm.editModalReporteFelicitaciones,
                  },
                  on: {
                    "update:show": function ($event) {
                      _vm.editModalReporteFelicitaciones = $event
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { attrs: { slot: "footer" }, slot: "footer" },
                    [
                      _c(
                        "CCol",
                        { attrs: { sm: "6" } },
                        [
                          _c(
                            "CButton",
                            {
                              attrs: { color: "success", variant: "outline" },
                              on: {
                                click: function ($event) {
                                  _vm.editModalReporteFelicitaciones = false
                                },
                              },
                            },
                            [_vm._v(" Cerrar\n            ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h3", { staticClass: "text-center" }, [
                    _vm._v("SOS - SISTEMA OPERATIVO DE SUGERENCIAS"),
                  ]),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c("table", { staticClass: "table" }, [
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesFelicitacion.fecha_realizada,
                                label: "Fecha:",
                                placeholder: "Ingrese fecha",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesFelicitacion,
                                    "fecha_realizada",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "60%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesFelicitacion.categoria,
                                label: "Categoria:",
                                placeholder: "Ingrese categoria",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesFelicitacion,
                                    "categoria",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value:
                                  _vm.reportesFelicitacion
                                    .nombre_realizo_reporte,
                                label: "Nombre:",
                                placeholder: "Ingrese Nombre",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesFelicitacion,
                                    "nombre_realizo_reporte",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "30%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value:
                                  _vm.reportesFelicitacion.puesto_evaluador,
                                label: "Puesto:",
                                placeholder: "Ingrese Puesto",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesFelicitacion,
                                    "puesto_evaluador",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "text-center" }, [
                    _vm._v(
                      "\n          Buen día, este espacio tiene como fin analizar la forma en que el personal\n          percibe el ambiente de trabajo en el que se desempeña, de esta manera con \n          la colaboración de todos podremos mejorar nuestro entorno laboral. Felicitación: \n          Expresa el reconocimiento a al persona o a el área por la satisfacción de la \n          atención brindada.\n        "
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b",
                    [
                      _c("CIcon", {
                        staticClass: "mb-1",
                        attrs: { name: "cil-user", size: "xl" },
                      }),
                      _vm._v(" "),
                      _c("h4", [_vm._v("Felicitación")]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesFelicitacion.comentarios,
                          disabled: "",
                          label: "¿A quien va dirigida tu felicitación?",
                          placeholder: "¿A quien va dirigida tu felicitación?",
                          rows: "1",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesFelicitacion,
                              "comentarios",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesFelicitacion.comentarios2,
                          disabled: "",
                          label: "Comentarios:",
                          placeholder: "¿Que deseas destacar?",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesFelicitacion,
                              "comentarios2",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CModal",
                {
                  attrs: {
                    entered: true,
                    title: "S.O.S. Sugerencia de mejora",
                    size: "xl",
                    show: _vm.editModalReporteSugerencia,
                  },
                  on: {
                    "update:show": function ($event) {
                      _vm.editModalReporteSugerencia = $event
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { attrs: { slot: "footer" }, slot: "footer" },
                    [
                      _c(
                        "CCol",
                        { attrs: { sm: "6" } },
                        [
                          _c(
                            "CButton",
                            {
                              attrs: { color: "success", variant: "outline" },
                              on: {
                                click: function ($event) {
                                  _vm.editModalReporteSugerencia = false
                                },
                              },
                            },
                            [_vm._v(" Cerrar\n            ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h3", { staticClass: "text-center" }, [
                    _vm._v("SOS - SISTEMA OPERATIVO DE SUGERENCIAS"),
                  ]),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c("table", { staticClass: "table" }, [
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesSugerencia.fecha_realizada,
                                label: "Fecha:",
                                placeholder: "Ingrese fecha",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesSugerencia,
                                    "fecha_realizada",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "60%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesSugerencia.categoria,
                                label: "Categoria:",
                                placeholder: "Ingrese categoria",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesSugerencia,
                                    "categoria",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value:
                                  _vm.reportesSugerencia.nombre_realizo_reporte,
                                label: "Nombre:",
                                placeholder: "Ingrese Nombre",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesSugerencia,
                                    "nombre_realizo_reporte",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "30%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesSugerencia.puesto_evaluador,
                                label: "Puesto:",
                                placeholder: "Ingrese Puesto",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesSugerencia,
                                    "puesto_evaluador",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "text-center" }, [
                    _vm._v(
                      "\n          Buen día, este espacio tiene como fin analizar la forma en que el personal\n          percibe el ambiente de trabajo en el que se desempeña, de esta manera con \n          la colaboración de todos podremos mejorar nuestro entorno laboral. Sugerencia: \n          Expresa toda aquella propuesta que tenga por finalidad promover la mejora \n          de la calidad mediante la aportación de ideas o iniciativas para perfeccionar \n          el funcionamiento de la organización.\n        "
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b",
                    [
                      _c("CIcon", {
                        staticClass: "mb-1",
                        attrs: { name: "cil-user", size: "xl" },
                      }),
                      _vm._v(" "),
                      _c("h4", [_vm._v("Sugerencia de mejora")]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesSugerencia.comentarios,
                          label: "Descripcion",
                          placeholder:
                            "Escribe una descripcion de la situacion",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesSugerencia,
                              "comentarios",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesSugerencia.comentarios2,
                          label: "¿Que haria usted?",
                          placeholder:
                            "Desde tu punto de vista ¿Que solucion/mejora propondrias?",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesSugerencia,
                              "comentarios2",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesSugerencia.comentarios3,
                          label: "¿Que esperas de la empresa?",
                          placeholder:
                            "Desde tu punto de vista ¿Que plan de accion esperas por parte de la empresa?",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesSugerencia,
                              "comentarios3",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CModal",
                {
                  attrs: {
                    entered: true,
                    title: "S.O.S. Queja",
                    size: "xl",
                    show: _vm.editModalReporteQueja,
                  },
                  on: {
                    "update:show": function ($event) {
                      _vm.editModalReporteQueja = $event
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { attrs: { slot: "footer" }, slot: "footer" },
                    [
                      _c(
                        "CCol",
                        { attrs: { sm: "6" } },
                        [
                          _c(
                            "CButton",
                            {
                              attrs: { color: "success", variant: "outline" },
                              on: {
                                click: function ($event) {
                                  _vm.editModalReporteQueja = false
                                },
                              },
                            },
                            [_vm._v(" Cerrar\n            ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h3", { staticClass: "text-center" }, [
                    _vm._v("SOS - SISTEMA OPERATIVO DE SUGERENCIAS"),
                  ]),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c("table", { staticClass: "table" }, [
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesQueja.fecha_realizada,
                                label: "Fecha:",
                                placeholder: "Ingrese fecha",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesQueja,
                                    "fecha_realizada",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "60%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesQueja.categoria,
                                label: "Categoria:",
                                placeholder: "Ingrese categoria",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesQueja,
                                    "categoria",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("tbody", { attrs: { width: "100%" } }, [
                      _c("tr", [
                        _c(
                          "th",
                          { attrs: { width: "40%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesQueja.nombre_realizo_reporte,
                                label: "Nombre:",
                                placeholder: "Ingrese nombre",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesQueja,
                                    "nombre_realizo_reporte",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { attrs: { width: "60%" } },
                          [
                            _c("CInput", {
                              attrs: {
                                value: _vm.reportesQueja.puesto_evaluador,
                                label: "Puesto:",
                                placeholder: "Ingrese puesto",
                                disabled: "",
                              },
                              on: {
                                "update:value": function ($event) {
                                  return _vm.$set(
                                    _vm.reportesQueja,
                                    "puesto_evaluador",
                                    $event
                                  )
                                },
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "text-center" }, [
                    _vm._v(
                      "\n          Buen día, este espacio tiene como fin analizar la forma en que el personal\n          percibe el ambiente de trabajo en el que se desempeña, de esta manera con \n          la colaboración de todos podremos mejorar nuestro entorno laboral. Queja: \n          Expresa la insatisfacción sobre los defectos de funcionamiento, estructura, \n          recursos, organización, trato, desatención, tardanza o cualquier otra imperfección.                         \n        "
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b",
                    [
                      _c("CIcon", {
                        staticClass: "mb-1",
                        attrs: { name: "cil-user", size: "xl" },
                      }),
                      _vm._v(" "),
                      _c("h4", [_vm._v("Queja")]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesQueja.comentarios,
                          label: "Descripcion",
                          placeholder:
                            "Escribe una descripcion de la situacion",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesQueja,
                              "comentarios",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesQueja.comentarios2,
                          label: "¿Que haria usted?",
                          placeholder:
                            "Desde tu punto de vista ¿Cuales son las medida que se deben tomar?",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesQueja,
                              "comentarios2",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          value: _vm.reportesQueja.comentarios3,
                          label: "¿Que esperas de la empresa?",
                          placeholder:
                            "Desde tu punto de vista ¿Que plan de accion esperas por parte de la empresa?",
                          disabled: "",
                          rows: "3",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(
                              _vm.reportesQueja,
                              "comentarios3",
                              $event
                            )
                          },
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);