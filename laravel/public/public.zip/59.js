(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[59],{

/***/ "../coreui/src/views/tickets/Ticket.vue":
/*!**********************************************!*\
  !*** ../coreui/src/views/tickets/Ticket.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Ticket.vue?vue&type=template&id=5635655e& */ "../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e&");
/* harmony import */ var _Ticket_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ticket.vue?vue&type=script&lang=js& */ "../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Ticket_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/tickets/Ticket.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Ticket_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Ticket.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Ticket_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e&":
/*!*****************************************************************************!*\
  !*** ../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e& ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Ticket.vue?vue&type=template&id=5635655e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Ticket_vue_vue_type_template_id_5635655e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/tickets/Ticket.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "../coreui/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/validators */ "../coreui/src/utils/validators.js");
/* harmony import */ var _vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @vuelidate/validators */ "../coreui/node_modules/@vuelidate/validators/dist/index.esm.js");
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @vuelidate/core */ "../coreui/node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _coreui_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @coreui/icons */ "../coreui/node_modules/@coreui/icons/js/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "../coreui/node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _shared_Comments__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/Comments */ "../coreui/src/views/shared/Comments.vue");
/* harmony import */ var _shared_History__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/History */ "../coreui/src/views/shared/History.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "../coreui/node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//








/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Comments: _shared_Comments__WEBPACK_IMPORTED_MODULE_6__["default"],
    History: _shared_History__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  name: "AdvancedTables",
  moodGood: _coreui_icons__WEBPACK_IMPORTED_MODULE_4__["cilMoodGood"],
  inputPower: _coreui_icons__WEBPACK_IMPORTED_MODULE_4__["cilInputPower"],
  plusIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_4__["cilPlus"],
  LightbulbIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_4__["cilLightbulb"],
  ticket: {
    id: "",
    folio: "",
    no_contrato: "",
    nombre_cliente: "",
    telefono: "",
    domicilio: "",
    ciudad: "",
    fecha: "",
    estatus: "",
    observaciones: "",
    fecha_instalacion: "",
    tipo_ajuste_componente: "",
    tipo_componente: "",
    serie_componente_anterior: "",
    serie_componente_nuevo: "",
    fecha_aprobado_visita: "",
    facturar_visita: "",
    factura_visita: "",
    servicio: "",
    tipo_servicio: "",
    fecha_programado: "",
    fecha_enproceso: "",
    fecha_reprogramado: "",
    factura_servicio: "",
    fecha_aprobado_servicio: ""
  },
  data: function data() {
    return {
      busNoContrato: "",
      busEstatus: [],
      errors: [],
      servicios: [],
      tipos_servicios: [],
      tipos_servicios_estructuras: [],
      tipos_servicios_monitoreos: [],
      tipos_componentes: [],
      tipos_servicios_reparaciones: [],
      tipos_servicios_revisiones: [],
      tipos_ajuste_componentes: [],
      history: {},
      user: {},
      sino_lst: [{
        value: "1",
        label: 'Si'
      }, {
        value: "0",
        label: 'No'
      }],
      imprimirServicioLink: "",
      ticket: {
        id: "",
        folio: "",
        no_contrato: "",
        nombre_cliente: "",
        telefono: "",
        domicilio: "",
        ciudad: "",
        fecha: "",
        estatus: "",
        observaciones: "",
        fecha_instalacion: "",
        tipo_ajuste_componente: "",
        tipo_componente: "",
        serie_componente_anterior: "",
        serie_componente_nuevo: "",
        facturar_visita: "",
        factura_visita: "",
        servicio: "",
        tipo_servicio: "",
        fecha_aprobado_visita: "",
        fecha_programado: "",
        fecha_enproceso: "",
        fecha_reprogramado: "",
        factura_servicio: "",
        fecha_aprobado_servicio: ""
      }
    };
  },
  validations: function validations() {
    var _this = this,
        _ticket;

    return {
      ticket: (_ticket = {
        fecha_programado: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.estatus.code == 5;
          }),
          $autoDirty: true
        }
        /* { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.code == 5), $autoDirty: true }*/
        ,
        estatus: {
          required: _utils_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
          $autoDirty: true
        },
        observaciones: {
          required: _utils_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
          $autoDirty: true
        },
        tipo_servicio: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.servicio != 4 && _this.ticket.servicio != 6 && _this.ticket.servicio != 3 && _this.ticket.estatus.sort > 4 || _this.ticket.estatus && _this.ticket.servicio == 3 && _this.ticket.estatus.code == 2;
          }),
          $autoDirty: true
        },
        factura_visita: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.estatus.code == 1 && _this.ticket.facturar_visita == 1;
          }),
          $autoDirty: true
        },
        fecha_enproceso: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.estatus.code == 6 && _this.ticket.estatus.sort >= 2;
          }),
          $autoDirty: true
        },
        fecha_aprobado_servicio: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.estatus.code == 8 && _this.ticket.estatus.sort >= 7;
          }),
          $autoDirty: true
        },
        //factura_servicio: { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.code == 2 && strlen(this.ticket.factura_servicio) > 0) , $autoDirty: true},
        //tipos_componente: { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.sort >= 4 && this.ticket.estatus.sort == 6), $autoDirty: true },
        serie_componente_anterior: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.servicio == 2 && _this.ticket.tipo_servicio == 5 && (_this.ticket.tipo_componente == 1 || _this.ticket.tipo_componente == 2);
          }),
          $autoDirty: true
        }
        /* { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.code == 5), $autoDirty: true }*/
        ,
        serie_componente_nuevo: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.servicio == 2 && _this.ticket.tipo_servicio == 5 && (_this.ticket.tipo_componente == 1 || _this.ticket.tipo_componente == 2);
          }),
          $autoDirty: true
        }
        /* { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.code == 5), $autoDirty: true }*/
        ,
        tipo_componente: {
          required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
            return _this.ticket.estatus && _this.ticket.servicio == 2 && _this.ticket.tipo_servicio == 5 && (_this.ticket.tipo_componente == 1 || _this.ticket.tipo_componente == 2);
          }),
          $autoDirty: true
        }
        /* { required: requiredIf(() => this.ticket.estatus && this.ticket.estatus.code == 5), $autoDirty: true }*/

      }, _defineProperty(_ticket, "tipo_componente", {
        required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
          return _this.ticket.estatus && _this.ticket.servicio == 1 && _this.ticket.tipo_servicio == 3;
        }),
        $autoDirty: true
      }), _defineProperty(_ticket, "tipo_ajuste_componente", {
        required: Object(_vuelidate_validators__WEBPACK_IMPORTED_MODULE_2__["requiredIf"])(function () {
          return _this.ticket.estatus && _this.ticket.servicio == 2 && _this.ticket.tipo_servicio == 4 && (_this.ticket.tipo_componente == 1 || _this.ticket.tipo_componente == 2);
        }),
        $autoDirty: true
      }), _ticket)
    };
  },
  setup: function setup() {
    return {
      v$: Object(_vuelidate_core__WEBPACK_IMPORTED_MODULE_3__["useVuelidate"])()
    };
  },
  methods: {
    index: function index() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_5___default.a.get(this.$apiAdress + "/api/ticket/" + self.$route.params.id + "?token=" + localStorage.getItem("api_token")).then(function (response) {
        var tk = response.data.ticket;
        var orden = response.data.orden;
        self.user = response.data.user;
        console.log(tk);
        self.ticket.id = tk.id;
        self.ticket.folio = tk.folio;
        self.ticket.no_contrato = tk.orden.no_contrato;
        self.ticket.nombre_cliente = tk.orden.nombre_cliente;
        self.ticket.telefono = tk.orden.telefono;
        self.ticket.observaciones = tk.observaciones;
        self.ticket.fecha = moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.created_at)).format("YYYY-MM-DD");
        self.ticket.estatus = tk.estatus;
        self.ticket.domicilio = tk.orden.calle + " #" + tk.orden.numero + " " + tk.orden.colonia + " cp. " + tk.orden.cp;
        self.ticket.ciudad = orden.sucursal.name;
        self.imprimirServicioLink = "/api/ticket/imprimirservicio/" + self.$route.params.id + "?token=" + localStorage.getItem("api_token");
        self.ticket.fecha_instalacion = moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.orden.fecha_instalacion)).format("YYYY-MM-DD");
        self.ticket.tipo_ajuste_componente = tk.tipo_ajuste_componente;
        self.ticket.tipo_componente = tk.tipo_componente;
        self.ticket.serie_componente_anterior = tk.serie_componente_anterior;
        self.ticket.serie_componente_nuevo = tk.serie_componente_nuevo;
        self.ticket.facturar_visita = tk.facturar_visita;
        self.servicios = response.data.servicios;
        self.ticket.servicio = tk.servicio;
        self.tipos_servicios = response.data.tipos_servicios;
        self.tipos_servicios_estructuras = response.data.tipos_servicios_estructuras;
        self.tipos_servicios_monitoreos = response.data.tipos_servicios_monitoreos;
        self.tipos_componentes = response.data.tipos_componentes;
        self.tipos_servicios_reparaciones = response.data.tipos_servicios_reparaciones;
        self.tipos_servicios_revisiones = response.data.tipos_servicios_revisiones;
        self.tipos_ajuste_componentes = response.data.tipos_ajuste_componentes;
        self.ticket.tipo_servicio = tk.tipo_servicio;
        self.ticket.factura_visita = tk.factura_visita;
        self.ticket.fecha_aprobado_visita = tk.fecha_aprobado_visita ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_aprobado_visita)).format("YYYY-MM-DD") : "";
        self.ticket.fecha_programado = tk.fecha_programado ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_programado)).format("YYYY-MM-DD") : "";
        self.ticket.fecha_liquidado = tk.fecha_liquidado ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_liquidado)).format("YYYY-MM-DD") : "";
        self.ticket.fecha_enproceso = tk.fecha_enproceso ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_enproceso)).format("YYYY-MM-DD") : "";
        self.ticket.fecha_reprogramado = tk.fecha_reprogramado ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_reprogramado)).format("YYYY-MM-DD") : "";
        self.ticket.factura_servicio = tk.factura_servicio;
        self.ticket.fecha_aprobado_servicio = tk.fecha_aprobado_servicio ? moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_aprobado_servicio)).format("YYYY-MM-DD") : "";
      })["catch"](function (error) {
        if (error.response.status === 401) {
          self.$router.push({
            path: "/login"
          });
        } else {
          self.$toast.error(self.$t("messages.error"));
        }
      });
    },
    setEstatus: function setEstatus(estatus) {
      var _this2 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var self, isUpdate;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                self = _this2;
                self.v$.$touch();
                console.log(self.v$);

                if (!(estatus == 7)) {
                  _context.next = 9;
                  break;
                }

                if (!(_this2.ticket.fecha_reprogramado == "")) {
                  _context.next = 7;
                  break;
                }

                self.$toast.error("Debes de agregar una fecha de programción");
                return _context.abrupt("return");

              case 7:
                _context.next = 13;
                break;

              case 9:
                if (!(estatus == 8)) {
                  _context.next = 13;
                  break;
                }

                if (!(_this2.ticket.factura_servicio == null)) {
                  _context.next = 13;
                  break;
                }

                self.$toast.error("Debes de agregar una Factura al Servicio");
                return _context.abrupt("return");

              case 13:
                if (!self.v$.$error) {
                  _context.next = 16;
                  break;
                }

                console.log(self.v$);
                return _context.abrupt("return");

              case 16:
                _context.next = 18;
                return self.$swal({
                  title: self.$t("messages.question.status.title"),
                  text: self.$t("messages.question.status.description"),
                  icon: "warning",
                  showCancelButton: true
                }).then(function (result) {
                  return result.isConfirmed;
                });

              case 18:
                isUpdate = _context.sent;

                if (isUpdate) {
                  axios__WEBPACK_IMPORTED_MODULE_5___default.a.post(_this2.$apiAdress + "/api/ticket/estatus" + "?token=" + localStorage.getItem("api_token"), {
                    id: self.ticket.id,
                    estatus: estatus,
                    no_contrato: self.ticket.no_contrato,
                    observaciones: self.ticket.observaciones,
                    factura_visita: self.ticket.factura_visita,
                    fecha_aprobado_visita: self.ticket.fecha_aprobado_visita,
                    fecha_programado: self.ticket.fecha_programado,
                    fecha_enproceso: self.ticket.fecha_enproceso,
                    fecha_reprogramado: self.ticket.fecha_reprogramado,
                    tipo_ajuste_componente: self.ticket.tipo_ajuste_componente,
                    tipo_componente: self.ticket.tipo_componente,
                    serie_componente_anterior: self.ticket.serie_componente_anterior,
                    serie_componente_nuevo: self.ticket.serie_componente_nuevo,
                    factura_servicio: self.ticket.factura_servicio,
                    tipo_servicio: self.ticket.tipo_servicio,
                    fecha_aprobado_servicio: self.ticket.fecha_aprobado_servicio
                  }).then(function (response) {
                    var tk = response.data.ticket;
                    self.ticket.id = tk.id;
                    self.ticket.observaciones = tk.observaciones;
                    self.ticket.estatus = tk.estatus;
                    self.ticket.fecha_aprobado_visita = moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_aprobado_visita)).format("YYYY-MM-DD");
                    self.fecha_enproceso = moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_enproceso)).format("YYYY-MM-DD");
                    self.fecha_programado = moment__WEBPACK_IMPORTED_MODULE_8___default()(String(tk.fecha_programado)).format("YYYY-MM-DD");
                    self.$toast.success(self.$t("messages.insert"));
                  })["catch"](function (error) {
                    //console.log(error);
                    if (error.response.data.message == "The given data was invalid.") {
                      self.message = "";
                      self.errors = error.response.data.errors;

                      for (var key in error.response.data.errors) {
                        if (error.response.data.errors.hasOwnProperty(key)) {
                          self.message += error.response.data.errors[key][0] + "  ";
                        }
                      }

                      self.$toast.error(self.message);
                    } else if (error.response.status === 401) {
                      self.$router.push({
                        path: "/login"
                      });
                    } else {
                      self.$toast.error(self.$t("messages.error"));
                    }
                  });
                }

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    create: function create() {
      var self = this;
      this.v$.$touch();
      if (this.v$.$error) return;
      axios__WEBPACK_IMPORTED_MODULE_5___default.a.post(this.$apiAdress + "/api/ticket/create" + "?token=" + localStorage.getItem("api_token"), {
        no_contrato: self.ticket.no_contrato,
        observaciones: self.ticket.observaciones,
        id_orden: self.ticket.id_orden
      }).then(function (response) {
        var data = response.data;
        self.reset();
        self.$toast.success(self.$t("messages.insert"));
        self.$router.push({
          path: "/tickets"
        });
      })["catch"](function (error) {
        if (error.response.data.message == "The given data was invalid.") {
          self.message = "";
          self.errors = error.response.data.errors;

          for (var key in error.response.data.errors) {
            if (error.response.data.errors.hasOwnProperty(key)) {
              self.message += error.response.data.errors[key][0] + "  ";
            }
          }

          self.$toast.error(self.message);
        } else if (error.response.status === 401) {
          self.$router.push({
            path: "/login"
          });
        } else {
          self.$toast.error(self.$t("messages.error"));
        }
      });
    }
  },
  mounted: function mounted() {
    this.index();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/tickets/Ticket.vue?vue&type=template&id=5635655e& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "CCard",
        [
          _c(
            "CCardHeader",
            [
              _c("CIcon", {
                staticClass: "mt-1",
                attrs: { name: "cil-pin", size: "xl" },
              }),
              _vm._v(" "),
              _c("span", { staticClass: "h4" }, [
                _vm._v("Detalle orden de servicio "),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCardBody",
            [
              _c(
                "CRow",
                [
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Orden de Servicio",
                          placeholder: "Orden de Servicio",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.folio,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "folio", $$v)
                          },
                          expression: "ticket.folio",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "No. contrato",
                          placeholder: "No. contrato",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.no_contrato,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "no_contrato", $$v)
                          },
                          expression: "ticket.no_contrato",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "6" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Cliente",
                          placeholder: "Cliente",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.nombre_cliente,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "nombre_cliente", $$v)
                          },
                          expression: "ticket.nombre_cliente",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          type: "date",
                          label: "Fecha Instalación",
                          placeholder: "Fecha Instalación",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.fecha_instalacion,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "fecha_instalacion", $$v)
                          },
                          expression: "ticket.fecha_instalacion",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CSelect", {
                        attrs: {
                          value: _vm.ticket.servicio,
                          plain: true,
                          label: "Servicio",
                          placeholder: "Seleccione",
                          options: _vm.servicios,
                          disabled: "",
                        },
                        on: {
                          "update:value": function ($event) {
                            return _vm.$set(_vm.ticket, "servicio", $event)
                          },
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.servicio == 2 &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_servicio,
                              plain: true,
                              label: "Tipo de Servicio",
                              placeholder: "Seleccione",
                              options: _vm.tipos_servicios_revisiones,
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket.tipo_servicio
                                .$error
                                ? _vm.v$.ticket.tipo_servicio.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_servicio.$dirty
                                ? !_vm.v$.ticket.tipo_servicio.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_servicio",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.tipo_servicio == 4 &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_ajuste_componente,
                              plain: true,
                              label: "Ajuste Componente",
                              placeholder: "Seleccione",
                              options: _vm.tipos_ajuste_componentes,
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket
                                .tipo_ajuste_componente.$error
                                ? _vm.v$.ticket.tipo_ajuste_componente
                                    .$errors[0].$message
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_ajuste_componente
                                .$dirty
                                ? !_vm.v$.ticket.tipo_ajuste_componente.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_ajuste_componente",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.tipo_servicio == 5 &&
                  _vm.ticket.estatus.sort >= 3
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_componente,
                              plain: true,
                              label: "Cambio Componente",
                              placeholder: "Seleccione",
                              options: _vm.tipos_componentes,
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket.tipo_componente
                                .$error
                                ? _vm.v$.ticket.tipo_componente.$errors[0]
                                    .$message
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_componente.$dirty
                                ? !_vm.v$.ticket.tipo_componente.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_componente",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.tipo_servicio == 5 &&
                  (_vm.ticket.tipo_componente == 1 ||
                    _vm.ticket.tipo_componente == 2) &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "# Serie Anterior",
                              placeholder: "# Serie Anterior",
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket
                                .serie_componente_anterior.$error
                                ? _vm.v$.ticket.serie_componente_anterior
                                    .$errors[0].$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket
                                .serie_componente_anterior.$dirty
                                ? !_vm.v$.ticket.serie_componente_anterior
                                    .$invalid
                                : null,
                            },
                            model: {
                              value: _vm.ticket.serie_componente_anterior,
                              callback: function ($$v) {
                                _vm.$set(
                                  _vm.ticket,
                                  "serie_componente_anterior",
                                  $$v
                                )
                              },
                              expression: "ticket.serie_componente_anterior",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.tipo_servicio == 5 &&
                  (_vm.ticket.tipo_componente == 1 ||
                    _vm.ticket.tipo_componente == 2) &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "# Serie Nuevo",
                              placeholder: "# Serie Nuevo",
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket
                                .serie_componente_nuevo.$error
                                ? _vm.v$.ticket.serie_componente_nuevo
                                    .$errors[0].$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.serie_componente_nuevo
                                .$dirty
                                ? !_vm.v$.ticket.serie_componente_nuevo.$invalid
                                : null,
                            },
                            model: {
                              value: _vm.ticket.serie_componente_nuevo,
                              callback: function ($$v) {
                                _vm.$set(
                                  _vm.ticket,
                                  "serie_componente_nuevo",
                                  $$v
                                )
                              },
                              expression: "ticket.serie_componente_nuevo",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.servicio == 3 &&
                  _vm.ticket.estatus.sort > 4 &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_servicio,
                              plain: true,
                              label: "Tipo de Servicio",
                              placeholder: "Seleccione",
                              options: _vm.tipos_servicios_reparaciones,
                              disabled:
                                _vm.ticket.servicio != 3 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket.tipo_servicio
                                .$error
                                ? _vm.v$.ticket.tipo_servicio.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_servicio.$dirty
                                ? !_vm.v$.ticket.tipo_servicio.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_servicio",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.servicio == 5 &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_servicio,
                              plain: true,
                              label: "Tipo de Servicio",
                              placeholder: "Seleccione",
                              options: _vm.tipos_servicios_estructuras,
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket.tipo_servicio
                                .$error
                                ? _vm.v$.ticket.tipo_servicio.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_servicio.$dirty
                                ? !_vm.v$.ticket.tipo_servicio.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_servicio",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.servicio == 1 &&
                  _vm.ticket.estatus.sort >= 1
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_servicio,
                              plain: true,
                              label: "Tipo de Monitoreo",
                              placeholder: "Seleccione",
                              options: _vm.tipos_servicios_monitoreos,
                              disabled:
                                _vm.ticket.servicio == 1 ||
                                _vm.ticket.estatus.sort > 5,
                              "invalid-feedback": _vm.v$.ticket.tipo_servicio
                                .$error
                                ? _vm.v$.ticket.tipo_servicio.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_servicio.$dirty
                                ? !_vm.v$.ticket.tipo_servicio.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_servicio",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c("CCol", { attrs: { sm: "3" } }, [
                    _c("label", [_vm._v("¿Facturar O. de Servicio?")]),
                    _vm._v(" "),
                    _c("br"),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.ticket.facturar_visita,
                          expression: "ticket.facturar_visita",
                        },
                      ],
                      attrs: {
                        type: "radio",
                        id: "1",
                        value: "1",
                        disabled: _vm.ticket.estatus.sort > 0,
                      },
                      domProps: {
                        checked: _vm._q(_vm.ticket.facturar_visita, "1"),
                      },
                      on: {
                        change: function ($event) {
                          return _vm.$set(_vm.ticket, "facturar_visita", "1")
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("label", { attrs: { for: "uno" } }, [_vm._v("Si")]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.ticket.facturar_visita,
                          expression: "ticket.facturar_visita",
                        },
                      ],
                      attrs: {
                        type: "radio",
                        id: "0",
                        value: "0",
                        disabled: _vm.ticket.estatus.sort > 0,
                      },
                      domProps: {
                        checked: _vm._q(_vm.ticket.facturar_visita, "0"),
                      },
                      on: {
                        change: function ($event) {
                          return _vm.$set(_vm.ticket, "facturar_visita", "0")
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("label", { attrs: { for: "Dos" } }, [_vm._v("No")]),
                  ]),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Teléfono",
                          placeholder: "Teléfono",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.telefono,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "telefono", $$v)
                          },
                          expression: "ticket.telefono",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "5" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Domicilio",
                          placeholder: "Domicilio",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.domicilio,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "domicilio", $$v)
                          },
                          expression: "ticket.domicilio",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Ciudad",
                          placeholder: "Ciudad",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.ciudad,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "ciudad", $$v)
                          },
                          expression: "ticket.ciudad",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          type: "date",
                          label: "Fecha Ticket",
                          placeholder: "Fecha",
                          disabled: "",
                        },
                        model: {
                          value: _vm.ticket.fecha,
                          callback: function ($$v) {
                            _vm.$set(_vm.ticket, "fecha", $$v)
                          },
                          expression: "ticket.fecha",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "2" } },
                    [
                      _c("label", [_vm._v("Estatus")]),
                      _vm._v(" "),
                      _c(
                        "CButton",
                        {
                          attrs: {
                            variant: "outline",
                            color: _vm.ticket.estatus
                              ? _vm.ticket.estatus.aux
                              : "light",
                            block: "",
                          },
                        },
                        [
                          _vm._v(
                            "\n            " +
                              _vm._s(
                                _vm.ticket.estatus
                                  ? _vm.ticket.estatus.text
                                  : "Estatus"
                              ) +
                              "\n          "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.estatus.sort >= 1 &&
                  _vm.ticket.facturar_visita == 1
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "No. factura Visita",
                              placeholder: "No. factura",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 1,
                              "invalid-feedback": _vm.v$.ticket.factura_visita
                                .$error
                                ? _vm.v$.ticket.factura_visita.$errors[0]
                                    .$message
                                : "",
                              "is-valid":
                                _vm.v$.ticket.factura_visita.$dirty &&
                                _vm.ticket.estatus.code != 3 &&
                                _vm.ticket.estatus.code != 0
                                  ? !_vm.v$.ticket.factura_visita.$invalid
                                  : null,
                            },
                            model: {
                              value: _vm.ticket.factura_visita,
                              callback: function ($$v) {
                                _vm.$set(_vm.ticket, "factura_visita", $$v)
                              },
                              expression: "ticket.factura_visita",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm.ticket.estatus && _vm.ticket.estatus.sort >= 3
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              type: "date",
                              label: "Fecha Aprobado Visita",
                              placeholder: "Fecha",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 2,
                            },
                            model: {
                              value: _vm.ticket.fecha_aprobado_visita,
                              callback: function ($$v) {
                                _vm.$set(
                                  _vm.ticket,
                                  "fecha_aprobado_visita",
                                  $$v
                                )
                              },
                              expression: "ticket.fecha_aprobado_visita",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus && _vm.ticket.estatus.sort >= 3
                    ? _c(
                        "CCol",
                        {
                          attrs: { sm: "3" },
                          scopedSlots: _vm._u(
                            [
                              {
                                key: "append",
                                fn: function () {
                                  return [
                                    _c(
                                      "CButton",
                                      {
                                        attrs: {
                                          color: "secondary",
                                          disabled: "",
                                          size: "sm",
                                        },
                                      },
                                      [
                                        _c("CIcon", {
                                          attrs: { name: "cil-calendar" },
                                        }),
                                      ],
                                      1
                                    ),
                                  ]
                                },
                                proxy: true,
                              },
                            ],
                            null,
                            false,
                            3316365379
                          ),
                        },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "Fecha Programado",
                              type: "date",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 3,
                              "invalid-feedback": _vm.v$.ticket.fecha_programado
                                .$error
                                ? _vm.v$.ticket.fecha_programado.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.fecha_programado.$dirty
                                ? !_vm.v$.ticket.fecha_programado.$invalid
                                : null,
                            },
                            model: {
                              value: _vm.v$.ticket.fecha_programado.$model,
                              callback: function ($$v) {
                                _vm.$set(
                                  _vm.v$.ticket.fecha_programado,
                                  "$model",
                                  $$v
                                )
                              },
                              expression: "v$.ticket.fecha_programado.$model",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus && _vm.ticket.estatus.sort >= 4
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              type: "date",
                              label: "Fecha en Proceso",
                              placeholder: "Fecha",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 4,
                              "invalid-feedback": _vm.v$.ticket.fecha_enproceso
                                .$error
                                ? _vm.v$.ticket.fecha_enproceso.$errors[0]
                                    .$mesasage
                                : "",
                              "is-valid": _vm.v$.ticket.fecha_enproceso.$dirty
                                ? !_vm.v$.ticket.fecha_enproceso.$invalid
                                : null,
                            },
                            model: {
                              value: _vm.ticket.fecha_enproceso,
                              callback: function ($$v) {
                                _vm.$set(_vm.ticket, "fecha_enproceso", $$v)
                              },
                              expression: "ticket.fecha_enproceso",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.tipo_servicio == 3 &&
                  _vm.ticket.estatus.sort >= 5
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.ticket.tipo_componente,
                              plain: true,
                              label: "Componente Utilizado",
                              placeholder: "Seleccione",
                              options: _vm.tipos_componentes,
                              "invalid-feedback": _vm.v$.ticket.tipo_componente
                                .$error
                                ? _vm.v$.ticket.tipo_componente.$errors[0]
                                    .$message
                                : "",
                              "is-valid": _vm.v$.ticket.tipo_componente.$dirty
                                ? !_vm.v$.ticket.tipo_componente.$invalid
                                : null,
                            },
                            on: {
                              "update:value": function ($event) {
                                return _vm.$set(
                                  _vm.ticket,
                                  "tipo_componente",
                                  $event
                                )
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.estatus.sort >= 5 &&
                  (_vm.user.rol_id == 5 ||
                    _vm.user.rol_id == 10 ||
                    _vm.user.rol_id == 9 ||
                    _vm.user.rol_id == 3)
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              type: "date",
                              label: "Fecha Reprogramado",
                              placeholder: "Fecha",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 6,
                            },
                            model: {
                              value: _vm.ticket.fecha_reprogramado,
                              callback: function ($$v) {
                                _vm.$set(_vm.ticket, "fecha_reprogramado", $$v)
                              },
                              expression: "ticket.fecha_reprogramado",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus &&
                  _vm.ticket.estatus.sort >= 5 &&
                  (_vm.user.rol_id == 5 ||
                    _vm.user.rol_id == 10 ||
                    _vm.user.rol_id == 2)
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "No. factura Servicio / Componente",
                              placeholder: "No. factura",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 6,
                            },
                            model: {
                              value: _vm.ticket.factura_servicio,
                              callback: function ($$v) {
                                _vm.$set(_vm.ticket, "factura_servicio", $$v)
                              },
                              expression: "ticket.factura_servicio",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.ticket.estatus && _vm.ticket.estatus.sort >= 7
                    ? _c(
                        "CCol",
                        { attrs: { sm: "3" } },
                        [
                          _c("CInput", {
                            attrs: {
                              type: "date",
                              label: "Fecha Aprobado servicio",
                              placeholder: "No. factura",
                              disabled:
                                _vm.ticket.estatus &&
                                _vm.ticket.estatus.sort > 7,
                              "invalid-feedback": _vm.v$.ticket
                                .fecha_aprobado_servicio.$error
                                ? _vm.v$.ticket.fecha_aprobado_servicio
                                    .$errors[0].$message
                                : "",
                              "is-valid": _vm.v$.ticket.fecha_aprobado_servicio
                                .$dirty
                                ? !_vm.v$.ticket.fecha_aprobado_servicio
                                    .$invalid
                                : null,
                            },
                            model: {
                              value: _vm.ticket.fecha_aprobado_servicio,
                              callback: function ($$v) {
                                _vm.$set(
                                  _vm.ticket,
                                  "fecha_aprobado_servicio",
                                  $$v
                                )
                              },
                              expression: "ticket.fecha_aprobado_servicio",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          label: "Observaciones",
                          placeholder: "Observaciones",
                          rows: "9",
                          disabled: "",
                          "invalid-feedback": _vm.v$.ticket.observaciones.$error
                            ? _vm.v$.ticket.observaciones.$errors[0].$message
                            : "",
                          "is-valid":
                            _vm.v$.ticket.observaciones.$dirty &&
                            _vm.ticket.estatus.code != 3 &&
                            _vm.ticket.estatus.code != 0
                              ? !_vm.v$.ticket.observaciones.$invalid
                              : null,
                        },
                        model: {
                          value: _vm.v$.ticket.observaciones.$model,
                          callback: function ($$v) {
                            _vm.$set(_vm.v$.ticket.observaciones, "$model", $$v)
                          },
                          expression: "v$.ticket.observaciones.$model",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("CRow", { staticClass: "justify-content-between" }, [
                _vm.ticket.estatus && _vm.ticket.estatus.code != 3
                  ? _c(
                      "div",
                      { staticClass: "col-auto" },
                      [
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 4 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 2)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "dark" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("Facturar Visita\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 5 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 2)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "success" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("Visita Aprobada\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 6 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 9 ||
                          _vm.user.rol_id == 3)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "primary" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("Programado\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 2 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 9 ||
                          _vm.user.rol_id == 3)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "dark" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("En proceso\n            ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 7 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 2)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "info" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(8)
                                  },
                                },
                              },
                              [_vm._v("Factura\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 8 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 9 ||
                          _vm.user.rol_id == 3)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "warning" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(7)
                                  },
                                },
                              },
                              [_vm._v("ReProgramado\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 8 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 2)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "info" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("Factura Servicio\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        _vm.ticket.estatus.next == 9 &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 2)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "primary" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(
                                      _vm.ticket.estatus.next
                                    )
                                  },
                                },
                              },
                              [_vm._v("Aprobado Servicio\n          ")]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.ticket.estatus &&
                        (_vm.ticket.estatus.next == 3 ||
                          _vm.ticket.estatus.next == 8) &&
                        (_vm.user.rol_id == 5 ||
                          _vm.user.rol_id == 10 ||
                          _vm.user.rol_id == 6 ||
                          _vm.user.rol_id == 3)
                          ? _c(
                              "CButton",
                              {
                                staticClass: "mx-1",
                                attrs: { color: "success" },
                                on: {
                                  click: function ($event) {
                                    return _vm.setEstatus(3)
                                  },
                                },
                              },
                              [_vm._v("Finalizado\n            ")]
                            )
                          : _vm._e(),
                      ],
                      1
                    )
                  : _c("div", { staticClass: "col-auto" }),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-auto" },
                  [
                    _c(
                      "CLink",
                      {
                        staticClass: "btn mx-1 btn-outline-primary",
                        attrs: { href: _vm.imprimirServicioLink },
                      },
                      [_vm._v("\n            Imprimir Orden\n          ")]
                    ),
                    _vm._v(" "),
                    _vm.ticket.estatus &&
                    _vm.ticket.estatus.code != 0 &&
                    _vm.ticket.estatus.code != 3 &&
                    _vm.user.rol_id == 5
                      ? _c(
                          "CButton",
                          {
                            staticClass: "mx-1",
                            attrs: { color: "danger" },
                            on: {
                              click: function ($event) {
                                return _vm.setEstatus(0)
                              },
                            },
                          },
                          [_vm._v("Cancelar")]
                        )
                      : _vm._e(),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { md: "6" } },
            [
              _c("Comments", {
                attrs: {
                  ordenId: _vm.ticket.id,
                  user: _vm.user,
                  ordenEstatus: _vm.ticket.estatus
                    ? _vm.ticket.estatus.code
                    : 0,
                  commentType: "ticket",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { md: "6" } },
            [
              _c("History", {
                attrs: {
                  ordenId: _vm.ticket.id,
                  user: _vm.user,
                  commentType: "ticket",
                  history: _vm.history,
                },
              }),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);