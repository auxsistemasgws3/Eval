(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[58],{

/***/ "../coreui/src/views/requestsOff/RequestOff.vue":
/*!******************************************************!*\
  !*** ../coreui/src/views/requestsOff/RequestOff.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RequestOff.vue?vue&type=template&id=45e3da0e& */ "../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e&");
/* harmony import */ var _RequestOff_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RequestOff.vue?vue&type=script&lang=js& */ "../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RequestOff_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/requestsOff/RequestOff.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_RequestOff_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./RequestOff.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_RequestOff_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e&":
/*!*************************************************************************************!*\
  !*** ../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e& ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./RequestOff.vue?vue&type=template&id=45e3da0e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_RequestOff_vue_vue_type_template_id_45e3da0e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "../coreui/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/validators */ "../coreui/src/utils/validators.js");
/* harmony import */ var _shared_History__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/History */ "../coreui/src/views/shared/History.vue");
/* harmony import */ var _shared_Comments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/Comments */ "../coreui/src/views/shared/Comments.vue");
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @vuelidate/core */ "../coreui/node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _coreui_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @coreui/icons */ "../coreui/node_modules/@coreui/icons/js/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "../coreui/node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* import { requiredIf } from "@vuelidate/validators"; */






/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    History: _shared_History__WEBPACK_IMPORTED_MODULE_2__["default"],
    Comments: _shared_Comments__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  name: "AdvancedTables",
  moodGood: _coreui_icons__WEBPACK_IMPORTED_MODULE_5__["cilMoodGood"],
  inputPower: _coreui_icons__WEBPACK_IMPORTED_MODULE_5__["cilInputPower"],
  plusIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_5__["cilPlus"],
  LightbulbIcon: _coreui_icons__WEBPACK_IMPORTED_MODULE_5__["cilLightbulb"],
  requests: {
    id: "",
    no_contrato: "",
    nombre_cliente: "",
    telefono: "",
    domicilio: "",
    ciudad: "",
    estatus: "",
    observaciones: "",
    folio: "",
    planta: "",
    planta_usuario: "",
    fecha_solicitado: "",
    fecha_apagado: "",
    fecha_sprendido: "",
    fecha_prendido: "",
    diasEstatus: ""
  },
  data: function data() {
    return {
      busNoContrato: "",
      OpEstatus: [],
      cambioEstatus: "",
      banEditar: true,
      busEstatus: [],
      errors: [],
      user: {},
      requests: {
        id: "",
        no_contrato: "",
        nombre_cliente: "",
        telefono: "",
        domicilio: "",
        ciudad: "",
        estatus: "",
        observaciones: "",
        folio: "",
        planta: "",
        planta_usuario: "",
        fecha_solicitado: "",
        fecha_apagado: "",
        fecha_sprendido: "",
        fecha_prendido: "",
        diasEstatus: ""
      }
    };
  },
  validations: function validations() {
    return {
      requests: {
        estatus: {
          required: _utils_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
          $autoDirty: true
        },
        observaciones: {
          required: _utils_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
          $autoDirty: true
        }
      }
    };
  },
  setup: function setup() {
    return {
      v$: Object(_vuelidate_core__WEBPACK_IMPORTED_MODULE_4__["useVuelidate"])()
    };
  },
  methods: {
    index: function index() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_6___default.a.get(this.$apiAdress + "/api/request/" + self.$route.params.id + "?token=" + localStorage.getItem("api_token")).then(function (response) {
        var req = response.data.request;
        var orden = response.data.orden;
        self.OpEstatus = response.data.estatus;
        self.user = response.data.user;
        self.requests.id = req.id;
        self.requests.no_contrato = req.orden.no_contrato;
        self.requests.nombre_cliente = req.orden.nombre_cliente;
        self.requests.telefono = req.orden.telefono;
        self.requests.observaciones = req.observaciones;
        self.requests.folio = req.folio;
        self.requests.planta = req.orden.planta;
        self.requests.planta_usuario = req.orden.shinephone;
        self.requests.fecha_prendido = req.fecha_prendido ? moment(String(req.fecha_prendido)).format("YYYY-MM-DD") : "";
        self.requests.fecha_sprendido = req.fecha_sprendido ? moment(String(req.fecha_sprendido)).format("YYYY-MM-DD") : "";
        self.requests.fecha_apagado = req.fecha_apagado ? moment(String(req.fecha_apagado)).format("YYYY-MM-DD") : "";
        self.requests.fecha_solicitado = req.fecha_solicitado ? moment(String(req.fecha_solicitado)).format("YYYY-MM-DD") : "";
        self.requests.diasEstatus = response.data.diasEstatus;
        self.requests.estatus = req.estatus;
        req.orden.calle + " #" + req.orden.numero + " " + req.orden.colonia + " cp. " + req.orden.cp;
        self.requests.ciudad = orden.sucursal.name;
        /* self.imprimirServicioLink = "/api/ticket/imprimirservicio/" + self.$route.params.id +  "?token=" + localStorage.getItem("api_token") */
      })["catch"](function (error) {
        if (error.response.status === 401) {
          self.$router.push({
            path: "/login"
          });
        } else {
          self.$toast.error(self.$t("messages.error"));
        }
      });
    },
    setEstatus: function setEstatus(estatus) {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var self, isUpdate;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                self = _this;
                self.v$.$touch();

                if (!self.v$.$error) {
                  _context.next = 4;
                  break;
                }

                return _context.abrupt("return");

              case 4:
                _context.next = 6;
                return self.$swal({
                  title: self.$t("messages.question.status.title"),
                  text: self.$t("messages.question.status.description"),
                  icon: "warning",
                  showCancelButton: true
                }).then(function (result) {
                  return result.isConfirmed;
                });

              case 6:
                isUpdate = _context.sent;

                if (isUpdate) {
                  axios__WEBPACK_IMPORTED_MODULE_6___default.a.post(_this.$apiAdress + "/api/request/estatus" + "?token=" + localStorage.getItem("api_token"), {
                    id: self.requests.id,
                    estatus: estatus,
                    no_contrato: self.requests.no_contrato,
                    observaciones: self.requests.observaciones,
                    fecha_apagado: self.requests.fecha_apagado,
                    fecha_sprendido: self.requests.fecha_sprendido,
                    fecha_prendido: self.requests.fecha_prendido
                  }).then(function (response) {
                    var req = response.data.requests;
                    self.requests.id = req.id;
                    self.requests.observaciones = req.observaciones;
                    self.requests.estatus = req.estatus;
                    self.requests.fecha_prendido = req.fecha_prendido ? moment(String(req.fecha_prendido)).format("YYYY-MM-DD") : "";
                    self.requests.fecha_sprendido = req.fecha_sprendido ? moment(String(req.fecha_sprendido)).format("YYYY-MM-DD") : "";
                    self.requests.fecha_apagado = req.fecha_apagado ? moment(String(req.fecha_apagado)).format("YYYY-MM-DD") : "";
                    self.requests.fecha_solicitado = req.fecha_solicitado ? moment(String(req.fecha_solicitado)).format("YYYY-MM-DD") : "";
                    self.$toast.success(self.$t("messages.insert"));
                  })["catch"](function (error) {
                    console.log(error);

                    if (error.response.data.message == "The given data was invalid.") {
                      self.message = "";
                      self.errors = error.response.data.errors;

                      for (var key in error.response.data.errors) {
                        if (error.response.data.errors.hasOwnProperty(key)) {
                          self.message += error.response.data.errors[key][0] + "  ";
                        }
                      }

                      self.$toast.error(self.message);
                    } else if (error.response.status === 401) {
                      self.$router.push({
                        path: "/login"
                      });
                    } else {
                      self.$toast.error(self.$t("messages.error"));
                    }
                  });
                }

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    EditarRequests: function EditarRequests() {
      var _this2 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var self, isUpdate;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _this2.banEditar = !_this2.banEditar;
                self = _this2;
                _context2.next = 4;
                return self.$swal({
                  title: self.$t("messages.question.status.title"),
                  text: self.$t("messages.question.status.description"),
                  icon: "warning",
                  showCancelButton: true
                }).then(function (result) {
                  return result.isConfirmed;
                });

              case 4:
                isUpdate = _context2.sent;

                if (isUpdate) {
                  axios__WEBPACK_IMPORTED_MODULE_6___default.a.post(_this2.$apiAdress + "/api/request/editRequest" + "?token=" + localStorage.getItem("api_token"), {
                    id: self.requests.id,
                    editEstatus: self.cambioEstatus,
                    fecha_apagado: self.requests.fecha_apagado,
                    fecha_sprendido: self.requests.fecha_sprendido,
                    fecha_prendido: self.requests.fecha_prendido,
                    observaciones: self.requests.observaciones
                  }).then(function (response) {
                    /*
                    let data = response.data;
                    self.orden = data.orden;
                    self.orden.fecha_deposito = self.orden.fecha_deposito
                      ? moment(String(self.orden.fecha_deposito)).format("YYYY-MM-DD")
                      : "";
                    self.orden.fecha_instalacion = self.orden.fecha_instalacion
                      ? moment(String(self.orden.fecha_instalacion)).format(
                          "YYYY-MM-DD"
                        )
                      : "";
                    self.orden.fecha_inicio = self.orden.fecha_inicio
                      ? moment(String(self.orden.fecha_inicio)).format("YYYY-MM-DD")
                      : "";
                    self.orden.fecha_fin =
                      self.orden.estatus && self.orden.estatus.code != 9
                        ? self.orden.fecha_fin
                          ? moment(String(self.orden.fecha_fin)).format("YYYY-MM-DD")
                          : ""
                        : moment(new Date()).format("YYYY-MM-DD");
                    data.movimiento.created_at = data.movimiento.created_at
                      ? moment(String(self.orden.created_at)).format("YYYY-MM-DD")
                      : "";
                    self.movimientos.push(data.movimiento);
                    self.$toast.success(self.$t("messages.insert"));
                    */
                  })["catch"](function (error) {
                    //NuevoStatusSesion
                    if (error.response.status === 401) {
                      self.$router.push({
                        path: "/login"
                      });
                    } else {
                      self.$toast.error(self.$t("messages.error"));
                    }

                    if (error.response.data.message == "The given data was invalid.") {
                      self.message = "";
                      self.errors = error.response.data.errors;

                      for (var key in error.response.data.errors) {
                        if (error.response.data.errors.hasOwnProperty(key)) {
                          self.message += error.response.data.errors[key][0] + "  ";
                        }
                      }

                      self.$toast.error(self.message);
                    } else {
                      self.$toast.error(self.$t("messages.error"));
                    }
                  });
                }

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    }
  },
  mounted: function mounted() {
    this.index();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/requestsOff/RequestOff.vue?vue&type=template&id=45e3da0e& ***!
  \*******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "CCard",
        [
          _c(
            "CCardHeader",
            [
              _c("CIcon", {
                staticClass: "mt-1",
                attrs: { name: "cil-wifi-signal-off", size: "xl" },
              }),
              _vm._v(" "),
              _c("span", { staticClass: "h4" }, [
                _vm._v("Detalles de solicitud de apagado"),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCardBody",
            [
              _c(
                "CRow",
                [
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "No. contrato",
                          placeholder: "No. contrato",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.no_contrato,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "no_contrato", $$v)
                          },
                          expression: "requests.no_contrato",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Folio solicitud apagado",
                          placeholder: "Folio solicitud apagado",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.folio,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "folio", $$v)
                          },
                          expression: "requests.folio",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "6" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Cliente",
                          placeholder: "Cliente",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.nombre_cliente,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "nombre_cliente", $$v)
                          },
                          expression: "requests.nombre_cliente",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Teléfono",
                          placeholder: "Teléfono",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.telefono,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "telefono", $$v)
                          },
                          expression: "requests.telefono",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "5" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Domicilio",
                          placeholder: "Domicilio",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.domicilio,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "domicilio", $$v)
                          },
                          expression: "requests.domicilio",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Ciudad",
                          placeholder: "Ciudad",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.ciudad,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "ciudad", $$v)
                          },
                          expression: "requests.ciudad",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "2" } },
                    [
                      _c("CInput", {
                        attrs: {
                          type: "date",
                          label: "Fecha de solicitud apagado",
                          placeholder: "Fecha de solicitud apagado",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.fecha_solicitado,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "fecha_solicitado", $$v)
                          },
                          expression: "requests.fecha_solicitado",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.requests.estatus && _vm.requests.estatus.sort >= 2
                    ? _c(
                        "CCol",
                        { attrs: { sm: "2" } },
                        [
                          _c("CInput", {
                            attrs: {
                              label: "Fecha inversor apagado",
                              type: "date",
                              disabled:
                                _vm.banEditar &&
                                _vm.requests.estatus &&
                                _vm.requests.estatus.sort >= 2,
                            },
                            model: {
                              value: _vm.requests.fecha_apagado,
                              callback: function ($$v) {
                                _vm.$set(_vm.requests, "fecha_apagado", $$v)
                              },
                              expression: "requests.fecha_apagado",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.requests.estatus && _vm.requests.estatus.sort >= 3
                    ? _c(
                        "CCol",
                        { attrs: { sm: "2" } },
                        [
                          _c("CInput", {
                            attrs: {
                              disabled:
                                _vm.banEditar &&
                                _vm.requests.estatus &&
                                _vm.requests.estatus.sort >= 3,
                              type: "date",
                              label: "Fecha solicitud prendido",
                              placeholder: "Fecha solicitud prendido",
                            },
                            model: {
                              value: _vm.requests.fecha_sprendido,
                              callback: function ($$v) {
                                _vm.$set(_vm.requests, "fecha_sprendido", $$v)
                              },
                              expression: "requests.fecha_sprendido",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.requests.estatus && _vm.requests.estatus.sort >= 4
                    ? _c(
                        "CCol",
                        { attrs: { sm: "2" } },
                        [
                          _c("CInput", {
                            attrs: {
                              disabled:
                                _vm.banEditar &&
                                _vm.requests.estatus &&
                                _vm.requests.estatus.sort >= 4,
                              type: "date",
                              label: "Fecha inversor prendido",
                              placeholder: "Fecha inversor prendido",
                            },
                            model: {
                              value: _vm.requests.fecha_prendido,
                              callback: function ($$v) {
                                _vm.$set(_vm.requests, "fecha_prendido", $$v)
                              },
                              expression: "requests.fecha_prendido",
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "2" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Planta",
                          placeholder: "Planta",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.planta,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "planta", $$v)
                          },
                          expression: "requests.planta",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "3" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Nombre de usuario Shinephone",
                          placeholder: "Nombre de usuario Shinephone",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.planta_usuario,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "planta_usuario", $$v)
                          },
                          expression: "requests.planta_usuario",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "2" } },
                    [
                      _c("label", [_vm._v("Estatus")]),
                      _vm._v(" "),
                      _c(
                        "CButton",
                        {
                          attrs: {
                            variant: "outline",
                            color: _vm.requests.estatus
                              ? _vm.requests.estatus.aux
                              : "light",
                            block: "",
                          },
                        },
                        [
                          _vm._v(
                            "\n            " +
                              _vm._s(
                                _vm.requests.estatus
                                  ? _vm.requests.estatus.text
                                  : "Estatus"
                              ) +
                              "\n          "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.user.rol_id == 5 && !_vm.banEditar
                    ? _c(
                        "CCol",
                        { attrs: { sm: "2" } },
                        [
                          _c("CSelect", {
                            attrs: {
                              value: _vm.cambioEstatus,
                              plain: true,
                              label: "Cambiar estatus",
                              options: _vm.OpEstatus,
                              placeholder: "Selecciona una estatus",
                            },
                            on: {
                              "update:value": function ($event) {
                                _vm.cambioEstatus = $event
                              },
                            },
                          }),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "2" } },
                    [
                      _c("CInput", {
                        attrs: {
                          label: "Días en este estatus",
                          placeholder: "Días trascurridos en este estatus",
                          disabled: "",
                        },
                        model: {
                          value: _vm.requests.diasEstatus,
                          callback: function ($$v) {
                            _vm.$set(_vm.requests, "diasEstatus", $$v)
                          },
                          expression: "requests.diasEstatus",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { sm: "12" } },
                    [
                      _c("CTextarea", {
                        attrs: {
                          label: "Observaciones",
                          placeholder: "Observaciones",
                          rows: "9",
                          disabled:
                            _vm.user.rol_id != 5 && _vm.user.rol_id != 6,
                          "invalid-feedback": _vm.v$.requests.observaciones
                            .$error
                            ? _vm.v$.requests.observaciones.$errors[0].$message
                            : "",
                          "is-valid": _vm.v$.requests.observaciones.$dirty
                            ? !_vm.v$.requests.observaciones.$invalid
                            : null,
                        },
                        model: {
                          value: _vm.v$.requests.observaciones.$model,
                          callback: function ($$v) {
                            _vm.$set(
                              _vm.v$.requests.observaciones,
                              "$model",
                              $$v
                            )
                          },
                          expression: "v$.requests.observaciones.$model",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CRow",
                { staticClass: "justify-content-between" },
                [
                  _vm.requests.estatus && _vm.requests.estatus.code != 4
                    ? _c(
                        "div",
                        { staticClass: "col-auto" },
                        [
                          _vm.requests.estatus &&
                          _vm.requests.estatus.next == 2 &&
                          (_vm.user.rol_id == 6 ||
                            _vm.user.rol_id == 5 ||
                            _vm.user.rol_id == 10)
                            ? _c(
                                "CButton",
                                {
                                  staticClass: "mx-1",
                                  attrs: { color: "dark" },
                                  on: {
                                    click: function ($event) {
                                      return _vm.setEstatus(
                                        _vm.requests.estatus.next
                                      )
                                    },
                                  },
                                },
                                [_vm._v("Apagado")]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.requests.estatus &&
                          _vm.requests.estatus.next == 3 &&
                          (_vm.user.rol_id == 2 ||
                            _vm.user.rol_id == 5 ||
                            _vm.user.rol_id == 10)
                            ? _c(
                                "CButton",
                                {
                                  staticClass: "mx-1",
                                  attrs: { color: "success" },
                                  on: {
                                    click: function ($event) {
                                      return _vm.setEstatus(
                                        _vm.requests.estatus.next
                                      )
                                    },
                                  },
                                },
                                [_vm._v("Solicitud prender")]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.requests.estatus &&
                          _vm.requests.estatus.next == 4 &&
                          (_vm.user.rol_id == 6 ||
                            _vm.user.rol_id == 5 ||
                            _vm.user.rol_id == 10)
                            ? _c(
                                "CButton",
                                {
                                  staticClass: "mx-1",
                                  attrs: { color: "success" },
                                  on: {
                                    click: function ($event) {
                                      return _vm.setEstatus(
                                        _vm.requests.estatus.next
                                      )
                                    },
                                  },
                                },
                                [_vm._v("Prendido")]
                              )
                            : _vm._e(),
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "CCol",
                    { attrs: { md: "auto" } },
                    [
                      _vm.requests.estatus &&
                      _vm.requests.estatus.code != 0 &&
                      (_vm.user.rol_id == 5 || _vm.user.rol_id == 10) &&
                      _vm.banEditar
                        ? _c(
                            "CButton",
                            {
                              staticClass: "mx-1",
                              attrs: { color: "warning" },
                              on: {
                                click: function ($event) {
                                  _vm.banEditar = !_vm.banEditar
                                },
                              },
                            },
                            [_vm._v("Editar")]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.requests.estatus &&
                      _vm.requests.estatus.code != 0 &&
                      _vm.requests.estatus.code != 8 &&
                      (_vm.user.rol_id == 5 || _vm.user.rol_id == 10) &&
                      !_vm.banEditar
                        ? _c(
                            "CButton",
                            {
                              staticClass: "mx-1",
                              attrs: { color: "danger" },
                              on: {
                                click: function ($event) {
                                  _vm.banEditar = !_vm.banEditar
                                },
                              },
                            },
                            [_vm._v("Cancelar Editar")]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.requests.estatus &&
                      _vm.requests.estatus.code != 0 &&
                      (_vm.user.rol_id == 5 || _vm.user.rol_id == 10) &&
                      !_vm.banEditar
                        ? _c(
                            "CLink",
                            {
                              staticClass: "btn mx-1 btn-outline-primary",
                              on: {
                                click: function ($event) {
                                  return _vm.EditarRequests()
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n            Guardar Editado\n          "
                              ),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.requests.estatus &&
                      _vm.requests.estatus.code != 0 &&
                      _vm.requests.estatus.code != 3 &&
                      _vm.user.rol_id == 5
                        ? _c(
                            "CButton",
                            {
                              staticClass: "mx-1",
                              attrs: { color: "danger" },
                              on: {
                                click: function ($event) {
                                  return _vm.setEstatus(0)
                                },
                              },
                            },
                            [_vm._v("Cancelar")]
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { md: "6" } },
            [
              _c("Comments", {
                attrs: {
                  ordenId: _vm.requests.id,
                  user: _vm.user,
                  ordenEstatus: _vm.requests.estatus
                    ? _vm.requests.estatus.code
                    : 0,
                  commentType: "request",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { md: "6" } },
            [
              _c("History", {
                attrs: {
                  ordenId: _vm.requests.id,
                  user: _vm.user,
                  commentType: "request",
                  history: _vm.history,
                },
              }),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);